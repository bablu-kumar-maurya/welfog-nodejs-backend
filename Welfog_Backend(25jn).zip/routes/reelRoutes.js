const express = require("express");
const mongoose = require('mongoose');
const router = express.Router();
const Comment = require("../models/Comment");
const Reel = require("../models/Reel");
const User = require("../models/Users");
const Music = require("../models/Music"); // <-- import Music model
const multer = require("multer");
const logUserAction = require("../utils/logUserAction");
const fs = require("fs");
const path = require("path");
const ffmpeg = require("fluent-ffmpeg");
const ffmpegInstaller = require("@ffmpeg-installer/ffmpeg");
const tmp = require("tmp");
const http = require("http");
const https = require("https");
const os = require("os");
const ffprobeStatic = require('ffprobe-static');
const { uploadToS3 } = require("../lib/s3");
ffmpeg.setFfmpegPath(ffmpegInstaller.path);
const adminAuth = require("../middleware/adminAuth");
const checkPermission = require("../middleware/checkPermission");
const createNotification = require("../utils/createNotification");
const logError = require("../utils/logError");
const { generateShortLink } = require("../utils/shortLink");
const ReelInteraction = require('../models/ReelInteraction');

// ---------- Adaptive compressor (paste after ffmpeg.setFfmpegPath(...)) ----------
async function compressVideo(inputPath, outputPath) {
    const metadata = await new Promise((resolve, reject) => {
        ffmpeg.ffprobe(inputPath, (err, data) => {
            if (err) return reject(err);
            resolve(data);
        });
    });

    const video = metadata.streams.find(s => s.codec_type === "video");
    const width = video.width;
    const height = video.height;
    const duration = parseFloat(video.duration); // seconds

    const originalSizeMB = (fs.statSync(inputPath).size / (1024 * 1024));

    let crf, bps, scaleFilter;

    if (duration >= 60 && duration <= 180) {
        if (originalSizeMB <= 40) {
            crf = 23;
            bps = 1100;
        } else if (originalSizeMB <= 100) {
            crf = 25;
            bps = 900;
        } else {
            crf = 27;
            bps = 700;   
        }
        scaleFilter = "scale=720:-2";
    } else if (duration < 60) {
        crf = 20;
        bps = 1800;
        scaleFilter = "scale=720:-2";
    } else if (duration > 180) {
        crf = 28;
        bps = 650;
        scaleFilter = "scale=720:-2";
    }

    if (width < 1280) {
        scaleFilter = "scale=540:-2";
    }

    return new Promise((resolve, reject) => {
        ffmpeg(inputPath)
            .videoFilters(scaleFilter)
            .outputOptions([
                "-c:v libx264",
                `-b:v ${bps}k`,
                `-maxrate ${bps}k`,
                `-bufsize ${bps * 2}k`,
                `-crf ${crf}`,
                "-preset veryfast",
                "-c:a aac",
                "-b:a 128k",
                "-movflags +faststart",
                "-y"
            ])
            .save(outputPath)
            .on("end", resolve)
            .on("error", reject);
    });
}

// -------------------------------------------------------------------------------

const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 200 * 1024 * 1024 } // allow up to 200MB
});

ffmpeg.setFfprobePath(ffprobeStatic.path);
function getAudioDuration(filePath) {
    return new Promise((resolve, reject) => {
        ffmpeg.ffprobe(filePath, (err, metadata) => {
            if (err) {
                return reject(err);
            }
            const duration = metadata?.format?.duration;
            if (duration && !isNaN(parseFloat(duration))) {
                resolve(Math.round(parseFloat(duration)));
            } else {
                resolve(0);
            }
        });
    });
}

function getMediaDurationSec(filePath) {
    return new Promise((resolve, reject) => {
        ffmpeg.ffprobe(filePath, (err, metadata) => {
            if (err) return reject(err);
            const duration = parseFloat(metadata?.format?.duration);
            resolve(Number.isFinite(duration) && duration > 0 ? duration : 0);
        });
    });
}

function sanitizeCdnUrl(url) {
    if (!url || typeof url !== "string") return "";
    let s = url.trim();
    while (s.length > 0) {
        if (s.endsWith("%22")) {
            s = s.slice(0, -3).trimEnd();
            continue;
        }
        if (s.endsWith('"') || s.endsWith("'")) {
            s = s.slice(0, -1).trimEnd();
            continue;
        }
        break;
    }
    return s;
}

/** Overlay trimmed music (musicStartMs offset) onto the video clip. */
async function muxMusicOverVideo({
    videoPath,
    audioPath,
    outputPath,
    musicStartSec = 0,
    durationSec,
    musicVolume = 1,
    originalVolume = 0,
}) {
    const dur = Math.max(0.1, durationSec);
    const seek = Math.max(0, musicStartSec);
    const seekStr = seek.toFixed(3);
    const durStr = dur.toFixed(3);
    const mv = Math.min(1, Math.max(0, Number(musicVolume) || 0));
    const ov = Math.min(1, Math.max(0, Number(originalVolume) || 0));
    const mixOriginal = ov > 0.01;
    // Trim in the filter graph — input -ss is unreliable for the 2nd input with complex filters.
    const trimmedMusic = `[1:a]atrim=start=${seekStr}:duration=${durStr},asetpts=PTS-STARTPTS,volume=${mv.toFixed(4)}`;

    return new Promise((resolve, reject) => {
        const cmd = ffmpeg(videoPath).input(audioPath);

        if (mixOriginal) {
            cmd.complexFilter([
                `[0:a]volume=${ov.toFixed(4)}[orig]`,
                `${trimmedMusic}[music]`,
                `[orig][music]amix=inputs=2:duration=first:dropout_transition=0[aout]`,
            ]);
        } else {
            cmd.complexFilter([`${trimmedMusic}[aout]`]);
        }

        cmd.outputOptions([
            "-map", "0:v:0",
            "-map", "[aout]",
            "-c:v", "copy",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            "-y",
        ]);

        cmd.save(outputPath).on("end", resolve).on("error", reject);
    });
}

// =================================================================
// === 1. DOWNLOAD HELPER (Unchanged) ===
// =================================================================

async function downloadFileToTemp(url, ext = '.tmp') {
    const MAX_REDIRECTS = 5;
    let redirects = 0;
    let currentUrl = url;
    const tmpFile = tmp.fileSync({ postfix: ext });

    return new Promise((resolve, reject) => {
        function getFile(fileUrl) {
            if (redirects >= MAX_REDIRECTS) {
                tmpFile.removeCallback();
                return reject(new Error('Exceeded maximum redirects.'));
            }

            const getter = (fileUrl.startsWith("http://") ? http : https);
            getter.get(fileUrl, (response) => {
                const statusCode = response.statusCode;

                if (statusCode >= 300 && statusCode < 400 && response.headers.location) {
                    redirects++;
                    currentUrl = new URL(response.headers.location, fileUrl).href; 
                    response.resume(); 
                    return getFile(currentUrl); 
                }

                if (statusCode === 200) {
                    const file = fs.createWriteStream(tmpFile.name);
                    response.pipe(file);
                    file.on("finish", () => {
                        file.close(() => resolve(tmpFile));
                    });
                    file.on("error", (err) => {
                        tmpFile.removeCallback();
                        reject(err);
                    });
                    return;
                }

                tmpFile.removeCallback();
                return reject(new Error(`Failed to download file, Status Code: ${statusCode}`));

            }).on("error", (err) => {
                tmpFile.removeCallback();
                reject(err);
            });
        }
        getFile(currentUrl);
    });
}

async function convertMp4UrlToHlsAndUpdateReel(reelId, mp4Url) {
    const tempFiles = [];
    let hlsDir = null;
    try {
        const ext = path.extname(new URL(mp4Url).pathname) || ".mp4";
        const videoTmpObj = await downloadFileToTemp(mp4Url, ext);
        tempFiles.push(videoTmpObj);

        hlsDir = path.join(os.tmpdir(), `hls-${reelId}`);
        fs.mkdirSync(hlsDir, { recursive: true });

        // 👇 MAINE YAHAN CHANGE KIYA HAI: Sirf 480p rakha hai speed ke liye 👇
        const qualityVariants = [
            { name: "480p", resolution: "854x480", videoBitrate: "800k", audioBitrate: "96k", bandwidth: 1150000, hlsTime: 2 }
        ];

        const generateHLS = async (variant) => {
            const variantDir = path.join(hlsDir, variant.name);
            fs.mkdirSync(variantDir, { recursive: true });

            const segmentPattern = path.join(variantDir, "segment_%03d.ts").replace(/\\/g, '/');
            const outputPath = path.join(variantDir, "index.m3u8").replace(/\\/g, '/');

            return new Promise((resolve, reject) => {
                ffmpeg(videoTmpObj.name)
                    .videoFilters(`scale=${variant.resolution}:force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2`)
                    .videoCodec('libx264')
                    .audioCodec('aac')
                    .addOutputOptions([
                        "-preset", "veryfast",
                        `-b:v ${variant.videoBitrate}`,
                        `-maxrate ${variant.videoBitrate}`,
                        `-bufsize ${parseInt(variant.videoBitrate) * 2}k`,
                        `-b:a ${variant.audioBitrate}`,
                        "-sc_threshold", "0",
                        "-g", `${24 * variant.hlsTime}`,
                        "-keyint_min", `${24 * variant.hlsTime}`,
                        "-force_key_frames", `expr:gte(t,n_forced*${variant.hlsTime})`,
                        "-hls_time", `${variant.hlsTime}`,
                        "-hls_playlist_type", "vod",
                        "-hls_list_size", "0",
                        "-hls_flags", "independent_segments",
                        "-hls_segment_type", "mpegts",
                        `-hls_segment_filename`, segmentPattern,
                        "-f", "hls",
                        "-y",
                    ])
                    .output(outputPath)
                    .on("end", resolve)
                    .on("error", reject)
                    .run();
            });
        };

        await Promise.all(qualityVariants.map(generateHLS));

        const masterPlaylistContent = `#EXTM3U
#EXT-X-VERSION:3
#EXT-X-INDEPENDENT-SEGMENTS
${qualityVariants.map(variant =>
            `#EXT-X-STREAM-INF:BANDWIDTH=${variant.bandwidth},RESOLUTION=${variant.resolution}
${variant.name}/index.m3u8`
        ).join('\n')}
`;

        fs.writeFileSync(path.join(hlsDir, "master.m3u8"), masterPlaylistContent);

        for (const variant of qualityVariants) {
            const variantDir = path.join(hlsDir, variant.name);
            const files = fs.readdirSync(variantDir).filter(f => fs.statSync(path.join(variantDir, f)).isFile());
            for (const file of files) {
                const filePath = path.join(variantDir, file);
                const buffer = fs.readFileSync(filePath);
                await uploadToS3(
                    {
                        buffer,
                        originalname: file,
                        mimetype: file.endsWith(".m3u8")
                            ? "application/vnd.apple.mpegurl"
                            : file.endsWith(".ts")
                                ? "video/mp2t"
                                : "application/octet-stream",
                    },
                    `videos/reels/${reelId}/${variant.name}`,
                    true
                );
            }
        }

        const masterBuffer = fs.readFileSync(path.join(hlsDir, "master.m3u8"));
        await uploadToS3(
            { buffer: masterBuffer, originalname: "master.m3u8", mimetype: "application/vnd.apple.mpegurl" },
            `videos/reels/${reelId}`,
            true
        );

        const videoUrl = `https://${process.env.CLOUDFRONT_URL}/videos/reels/${reelId}/master.m3u8`;
        await Reel.findByIdAndUpdate(reelId, {
            videoUrl,
            status: "Published",
            qualityVariants: qualityVariants.map(q => q.name),
        });
    } catch (err) {
        await Reel.findByIdAndUpdate(reelId, { status: "Processing" });
          err.statusCode = err.statusCode || 500;
        await logError(req, err);
        console.error("MP4->HLS migration failed:", err);
    } finally {
        tempFiles.forEach((t) => { try { if (t) t.removeCallback(); } catch (e) { } });
        if (hlsDir) { try { fs.rmSync(hlsDir, { recursive: true, force: true }); } catch (e) { } }
    }
}

// =================================================================
// === 2. WORKER FUNCTION (Updated Logic in Step 3) ===
// =================================================================

async function processReelUpload(jobData) {
    console.log(`===== [WORKER: FULL UPLOAD JOB STARTED for user ${jobData.userid}] =====`);
    const { videoBuffer, videoOriginalname, thumbBuffer, reelId: existingReelId, externalAudioData, ...reelMetadata } = jobData;
    const {
        user, userid, username, name, caption, musicId,
        videoStartTime, videoEndTime, musicStartTime, musicEndTime,
    } = reelMetadata;
    const musicVol = Math.min(1, Math.max(0, parseFloat(externalAudioData?.musicVolume ?? 1)));
    const originalVol = Math.min(1, Math.max(0, parseFloat(externalAudioData?.originalVolume ?? 0)));

    const tempFiles = [];
    let videoFileWithFinalAudioPath = null;
    let finalMusicId = musicId || null;
    let newReelId = existingReelId && mongoose.Types.ObjectId.isValid(existingReelId)
        ? existingReelId
        : null;
    let savedReel = null;
    let hlsDir = null;

    try {
        if (newReelId) {
            savedReel = await Reel.findById(newReelId);
            if (!savedReel) {
                throw new Error(`Reel stub not found: ${newReelId}`);
            }
        }

        const inputTmp = tmp.fileSync({ postfix: path.extname(videoOriginalname) });
        tempFiles.push(inputTmp);
        fs.writeFileSync(inputTmp.name, videoBuffer);

        const outputTmp = tmp.fileSync({ postfix: ".mp4" });
        tempFiles.push(outputTmp);

        let videoToCompressPath = inputTmp.name;
        const videoStartMs = parseFloat(videoStartTime);
        const videoEndMs = parseFloat(videoEndTime);
        if (Number.isFinite(videoStartMs) && Number.isFinite(videoEndMs)) {
            const startSec = videoStartMs / 1000;
            const dur = (videoEndMs - videoStartMs) / 1000;
            if (dur > 0) {
                const trimmedTmp = tmp.fileSync({ postfix: ".mp4" });
                tempFiles.push(trimmedTmp);

                await new Promise((resolve, reject) => {
                    ffmpeg(inputTmp.name)
                        .seekInput(startSec)
                        .duration(dur)
                        .outputOptions(["-c", "copy", "-y"])
                        .save(trimmedTmp.name)
                        .on("end", resolve)
                        .on("error", reject);
                });

                videoToCompressPath = trimmedTmp.name;
            }
        }

     /* ===== COMPRESSION BYPASS KIYA HAI =====
        const trimmedClipSec =
            videoStartTime && videoEndTime
                ? (parseFloat(videoEndTime) - parseFloat(videoStartTime)) / 1000
                : 0;
        if (trimmedClipSec > 0 && trimmedClipSec <= 50) {
            console.log("-> Compressing trimmed clip for better upload quality...");
            await compressVideo(videoToCompressPath, outputTmp.name);
        } else {
            console.log("-> Copying video without re-encode (long clip)...");
            fs.copyFileSync(videoToCompressPath, outputTmp.name);
        }
        ========================================= */

        console.log("-> ⚡ BYPASSING Backend Compression for Faster Upload...");
        fs.copyFileSync(videoToCompressPath, outputTmp.name);

        try {
            const originalSize = (fs.statSync(inputTmp.name).size / (1024 * 1024)).toFixed(2);
            const compressedSize = (fs.statSync(outputTmp.name).size / (1024 * 1024)).toFixed(2);
            console.log(`📹 Video compression stats for ${videoOriginalname}:`);
            console.log(`   Original size  : ${originalSize} MB`);
            console.log(`   New size       : ${compressedSize} MB`);
        } catch (e) {
            e.statusCode = e.statusCode || 500;
            await logError(req, e);
            console.warn("Could not stat files for logging:", e.message);
        }

        videoFileWithFinalAudioPath = outputTmp.name;

        // Step 3: Handle Audio Logic (Replacement OR Extraction)
        let shouldReplaceAudio = false;
        let audioInputPath = null;
        let audioDuration = 0; 

        if (externalAudioData && externalAudioData.url && (!musicId || !mongoose.Types.ObjectId.isValid(musicId))) {
            console.log("[STEP 3.0] Processing external audio data from body (new Music track)...");
            try {
                const title = externalAudioData.title || "External Sound";
                const artist = externalAudioData.artist || "Unknown Artist";

                const existingMusic = await Music.findOne({ title, artist });

                if (existingMusic) {
                    console.log("[INFO] Music already exists. Reusing:", existingMusic._id);
                    finalMusicId = existingMusic._id;
                    shouldReplaceAudio = true;

                    const ext = path.extname(existingMusic.url) || '.mp3';
                    const musicTmpObj = await downloadFileToTemp(existingMusic.url, ext);
                    tempFiles.push(musicTmpObj);
                    audioInputPath = musicTmpObj.name;  
                } else {
                    const ext = path.extname(new URL(externalAudioData.url).pathname) || '.mp3';
                    const musicTmpObj = await downloadFileToTemp(externalAudioData.url, ext);
                    tempFiles.push(musicTmpObj);
                    audioInputPath = musicTmpObj.name;

                    audioDuration = await getAudioDuration(audioInputPath);

                    const audioBuffer = fs.readFileSync(audioInputPath);
                    const audioUploadResult = await uploadToS3(
                        {
                            buffer: audioBuffer,
                            originalname: `external-sound-${userid}-${Date.now()}${ext}`,
                            mimetype: ext === '.mp3' ? "audio/mp3" : "audio/mpeg",
                        },
                        `audio`
                    );

                    const musicUrl = audioUploadResult;

                    const newMusic = new Music({
                        title,
                        artist,
                        url: musicUrl,
                        duration: audioDuration,
                        uploadedBy: user,
                        thumbnail: externalAudioData.artwork || "",
                    });

                    const savedMusic = await newMusic.save();
                    finalMusicId = savedMusic._id;
                    shouldReplaceAudio = true;
                }
            } catch (e) {
                console.warn("[WARNING] External audio failed:", e.message);
                e.statusCode = e.statusCode || 500;
                await logError(req, e);
                audioInputPath = null;
                finalMusicId = musicId || null;
            }
        }

        if (!shouldReplaceAudio && finalMusicId && mongoose.Types.ObjectId.isValid(finalMusicId)) {
            const musicDoc = await Music.findById(finalMusicId);
            if (musicDoc?.url) {
                console.log("[STEP 3.1] Replacing original audio with existing music...");
                const ext = path.extname(musicDoc.url) || '.mp3';
                const musicTmpObj = await downloadFileToTemp(musicDoc.url, ext);
                tempFiles.push(musicTmpObj);
                audioInputPath = musicTmpObj.name;
                shouldReplaceAudio = true;
            }
        }
        
        if (shouldReplaceAudio) {
            const replacedTmp = tmp.fileSync({ postfix: ".mp4" });
            tempFiles.push(replacedTmp);
            const videoDurationSec = await getMediaDurationSec(outputTmp.name);
            const parsedMusicStart = parseFloat(musicStartTime);
            const parsedMusicEnd = parseFloat(musicEndTime);
            const musicStartMs = Number.isFinite(parsedMusicStart) ? parsedMusicStart : 0;
            const musicEndMs = Number.isFinite(parsedMusicEnd) ? parsedMusicEnd : 0;
            const musicStartSec = musicStartMs / 1000;
            let muxDurationSec = videoDurationSec;
            if (musicEndMs > musicStartMs) {
                const musicClipSec = (musicEndMs - musicStartMs) / 1000;
                muxDurationSec = Math.min(videoDurationSec, musicClipSec);
            }
            console.log(
                `[STEP 3] Mux music: start=${musicStartMs}ms, end=${musicEndMs}ms, ` +
                `duration=${muxDurationSec.toFixed(2)}s, musicVol=${musicVol}, origVol=${originalVol}`
            );

            await muxMusicOverVideo({
                videoPath: outputTmp.name,
                audioPath: audioInputPath,
                outputPath: replacedTmp.name,
                musicStartSec,
                durationSec: muxDurationSec,
                musicVolume: musicVol,
                originalVolume: originalVol,
            });

            videoFileWithFinalAudioPath = replacedTmp.name;
        } else {
            console.log("[STEP 3.2] Extracting and saving original audio...");
            const extractedAudioTmp = tmp.fileSync({ postfix: ".mp3" });
            tempFiles.push(extractedAudioTmp);

            await new Promise((resolve, reject) => {
                ffmpeg(outputTmp.name)
                    .outputOptions([
                        "-vn",
                        "-c:a libmp3lame",
                        "-b:a 128k",
                        "-y",
                    ])
                    .save(extractedAudioTmp.name)
                    .on("end", resolve)
                    .on("error", reject);
            });

            const audioBuffer = fs.readFileSync(extractedAudioTmp.name);
            const audioUploadResult = await uploadToS3(
                {
                    buffer: audioBuffer,
                    originalname: `original-sound-${userid}-${Date.now()}.mp3`,
                    mimetype: "audio/mp3",
                },
                `audio`
            );

            if (!audioUploadResult) {
                throw new Error("S3 Upload failed to return a URL for the extracted audio.");
            }
            const musicUrl = audioUploadResult;

            let originalAudioDuration = 0;
            const videoDurationMs = (parseFloat(videoEndTime) - parseFloat(videoStartTime));
            if (!isNaN(videoDurationMs) && videoDurationMs > 0) {
                originalAudioDuration = Math.round(videoDurationMs / 1000);
            }

            const newMusic = new Music({
                title: caption ? `${caption.substring(0, 50)}... (Original Sound)` : "Original Video Sound",
                artist: name || username || 'Unknown User',
                url: musicUrl,
                duration: originalAudioDuration,
                uploadedBy: user,
                thumbnail: '',
            });

            const savedMusic = await newMusic.save();
            finalMusicId = savedMusic._id;
        }

        const uploaderUser = await User.findById(user);

        if (savedReel) {
            savedReel.music = finalMusicId;
            savedReel.caption = caption ?? savedReel.caption;
            savedReel.username = username || savedReel.username;
            savedReel.name = name || savedReel.name;
            await savedReel.save();
            newReelId = savedReel._id;
        } else {
            const newReel = new Reel({
                ...reelMetadata,
                music: finalMusicId,
                videoUrl: "",
                thumbnailUrl: "",
                seller_id: uploaderUser?.seller_id || "",
                userseller_id: uploaderUser?.userseller_id || "",
            });
            savedReel = await newReel.save();
            newReelId = savedReel._id;
        }

        try {
            if (uploaderUser && savedReel.shortLinks.length === 0) {
                const realUserId = uploaderUser.userid; 
                const { slug, shortLink } = generateShortLink(
                    savedReel._id,
                    realUserId
                );

                savedReel.shortLinks.push({
                    slug,
                    shortLink,
                    generatedForUser: uploaderUser._id,
                    generatedAt: new Date()
                });

                await savedReel.save();
                console.log(`[STEP 4.5] Short link generated and saved: ${shortLink}`);
            }
        } catch (shortLinkError) {
            shortLinkError.statusCode = shortLinkError.statusCode || 500;
            await logError(req, shortLinkError);
            console.warn("[WARNING] Failed to generate short link (non-blocking):", shortLinkError.message);
        }
console.log("[STEP 5] Generating HLS segments (Priority 1: 480p for Instant Live)...");
        hlsDir = path.join(os.tmpdir(), `hls-${newReelId}`);
        fs.mkdirSync(hlsDir, { recursive: true });

        // Helper function for FFmpeg Generation & S3 Upload
        const generateAndUploadVariant = async (variant) => {
            const variantDir = path.join(hlsDir, variant.name);
            fs.mkdirSync(variantDir, { recursive: true });

            const segmentPattern = path.join(variantDir, "segment_%03d.ts").replace(/\\/g, '/');
            const outputPath = path.join(variantDir, "index.m3u8").replace(/\\/g, '/');

            // 1. Generate HLS via FFmpeg
            await new Promise((resolve, reject) => {
                ffmpeg(videoFileWithFinalAudioPath)
                    .videoFilters(`scale=${variant.resolution}:force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2`)
                    .videoCodec('libx264')
                    .audioCodec('aac')
                    .addOutputOptions([
                        "-preset", "veryfast",
                        `-b:v ${variant.videoBitrate}`,
                        `-maxrate ${variant.videoBitrate}`,
                        `-bufsize ${parseInt(variant.videoBitrate) * 2}k`,
                        `-b:a ${variant.audioBitrate}`,
                        "-sc_threshold", "0",
                        "-g", `${24 * variant.hlsTime}`,       
                        "-keyint_min", `${24 * variant.hlsTime}`,
                        "-force_key_frames", `expr:gte(t,n_forced*${variant.hlsTime})`,
                        "-hls_time", `${variant.hlsTime}`,
                        "-hls_playlist_type", "vod",
                        "-hls_list_size", "0",
                        "-hls_flags", "independent_segments",
                        "-hls_segment_type", "mpegts",
                        `-hls_segment_filename`, segmentPattern,
                        "-f", "hls",
                        "-y",
                    ])
                    .output(outputPath)
                    .on("start", (cmd) => console.log(`[FFmpeg] Command for ${variant.name}: ${cmd}`))
                    .on("end", () => {
                        console.log(`[FFmpeg] Generated ${variant.name} variant`);
                        resolve();
                    })
                    .on("error", (err, stdout, stderr) => {
                        console.error(`[FFmpeg] ERROR for ${variant.name}:`, err.message);
                        reject(err);
                    })
                    .run();
            });

            // 2. Upload to S3 immediately after generation
            console.log(`[STEP 7] Uploading ${variant.name} files to S3...`);
            const files = fs.readdirSync(variantDir).filter(f => fs.statSync(path.join(variantDir, f)).isFile());
            
            const uploadPromises = files.map(file => {
                const filePath = path.join(variantDir, file);
                const buffer = fs.readFileSync(filePath);
                const s3Folder = `videos/reels/${newReelId}/${variant.name}`; 
                const mimetype = file.endsWith(".m3u8") ? "application/vnd.apple.mpegurl" : 
                                 file.endsWith(".ts") ? "video/mp2t" : "application/octet-stream";

                return uploadToS3({ buffer, originalname: file, mimetype }, s3Folder, true);
            });

            // Concurrency control for S3 Uploads (Max 4 at a time)
            while (uploadPromises.length > 0) {
                await Promise.all(uploadPromises.splice(0, 4));
            }
            console.log(`[STEP 7] Finished uploading variant: ${variant.name}`);
        };

        // --- 1. GENERATE & UPLOAD 480p FIRST ---
        await generateAndUploadVariant({
            name: "480p", resolution: "854x480", videoBitrate: "1100k", audioBitrate: "128k", bandwidth: 1400000, hlsTime: 2
        });

        // --- 2. CREATE & UPLOAD MASTER PLAYLIST ---
        console.log("[STEP 5] Creating master playlist...");
        const masterPlaylistContent = `#EXTM3U
#EXT-X-VERSION:3
#EXT-X-INDEPENDENT-SEGMENTS
#EXT-X-STREAM-INF:BANDWIDTH=380000,RESOLUTION=426x240
240p/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=1400000,RESOLUTION=854x480
480p/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2500000,RESOLUTION=1280x720
720p/index.m3u8
`;
        fs.writeFileSync(path.join(hlsDir, "master.m3u8"), masterPlaylistContent);
        const masterBuffer = fs.readFileSync(path.join(hlsDir, "master.m3u8"));
        await uploadToS3(
            { buffer: masterBuffer, originalname: "master.m3u8", mimetype: "application/vnd.apple.mpegurl" },
            `videos/reels/${newReelId}`,
            true
        );

        // --- 3. HANDLE THUMBNAIL ---
        console.log("[STEP 6] Handling thumbnail...");
        let thumbnailUrl = null;
        if (thumbBuffer) {
            thumbnailUrl = await uploadToS3({ buffer: thumbBuffer, originalname: `thumb-${newReelId}.jpg`, mimetype: "image/jpeg" }, "thumbnails");
        } else {
            const thumbTmp = tmp.fileSync({ postfix: ".jpg" });
            tempFiles.push(thumbTmp);
            await new Promise((resolve, reject) => {
                ffmpeg(videoFileWithFinalAudioPath).screenshots({ timestamps: [0], filename: path.basename(thumbTmp.name), folder: path.dirname(thumbTmp.name), size: "640x?", })
                    .on("end", resolve).on("error", reject);
            });
            const thumbBufferFromFile = fs.readFileSync(thumbTmp.name);
            thumbnailUrl = await uploadToS3({ buffer: thumbBufferFromFile, originalname: `thumb-${newReelId}.jpg`, mimetype: "image/jpeg", }, "thumbnails");
        }

        if (!musicId && finalMusicId) {
            await Music.findByIdAndUpdate(finalMusicId, { thumbnail: thumbnailUrl });
        }

        // --- 4. PUBLISH REEL IMMEDIATELY ---
        const videoUrl = `https://${process.env.CLOUDFRONT_URL}/videos/reels/${newReelId}/master.m3u8`;
        savedReel.videoUrl = sanitizeCdnUrl(videoUrl);
        savedReel.thumbnailUrl = sanitizeCdnUrl(thumbnailUrl);
        savedReel.status = 'Published'; 
        savedReel.qualityVariants = ["480p"]; // User ko turant video dikhne lagegi
        await savedReel.save();
        console.log("===== 🟢 [PRIORITY DONE: REEL IS PUBLISHED & LIVE!] =====");


        // --- 5. GENERATE 240p & 720p IN BACKGROUND (Awaited to keep temp files safe) ---
        console.log("-> ⏳ Now generating 240p & 720p in the background...");
        const remainingVariants = [
            { name: "240p", resolution: "426x240", videoBitrate: "350k", audioBitrate: "64k", bandwidth: 450000, hlsTime: 2 },
            { name: "720p", resolution: "1280x720", videoBitrate: "2000k", audioBitrate: "160k", bandwidth: 2500000, hlsTime: 2 }
        ];

        for (const variant of remainingVariants) {
            await generateAndUploadVariant(variant);
        }

        // Update DB once everything is done
        await Reel.findByIdAndUpdate(newReelId, {
            $addToSet: { qualityVariants: { $each: ["240p", "720p"] } }
        });

        console.log("===== [WORKER: FULL UPLOAD SUCCESS - ALL QUALITIES READY] =====");

    } catch (err) {
        console.error("===== [WORKER: FULL UPLOAD ERROR] =====");
        console.error(err);
        err.statusCode = err.statusCode || 500;
        // logError requires req, but req is not available in this worker function scope directly unless passed
        // Safely catch logError if req is missing
        try { await logError(req, err); } catch(e) {} 
        
        if (newReelId) {
            await Reel.findByIdAndUpdate(newReelId, { status: 'failed', error: err.message });
        }
        throw err;
    } finally {
        // Step 9: Cleanup temporary files and directory
        tempFiles.forEach((t) => { try { if (t) t.removeCallback(); } catch (e) { console.warn("Could not remove temp file:", e.message); } });
        if (hlsDir) { try { fs.rmSync(hlsDir, { recursive: true, force: true }); } catch (e) { console.warn("Could not remove HLS directory:", e.message); } }
    }
}
// =================================================================
// === 3. EXPRESS ROUTE (Updated Logic for audioData) ===
// =================================================================
router.post(
    "/full-upload",
    upload.fields([
        { name: "video", maxCount: 1 },
        { name: "thumbnail", maxCount: 1 },
    ]),
    async (req, res) => {
        console.log("===== [FULL UPLOAD API HIT] =====");
        try {
            const {
                user, userid, username, name, caption, musicId, audioData,
                videoStartTime, videoEndTime, musicStartTime, musicEndTime,
            } = req.body;

            let uploaderUser = null;

            if (user && mongoose.isValidObjectId(user)) {
                uploaderUser = await User.findById(user).select("isSuspended").lean();
            }

            if (!uploaderUser && userid) {
                uploaderUser = await User.findOne({ userid }).select("isSuspended").lean();
            }

            if (uploaderUser?.isSuspended) {
                return res.status(403).json({
                    success: false,
                    message: "Your account is suspended. You cannot upload videos."
                });
            }

            let parsedAudioData = null;
            if (audioData) {
                try {
                    parsedAudioData = JSON.parse(audioData);
                } catch (e) {
                    await logError(req, e);
                    console.error("Error parsing audioData:", e);
                }
            }

            console.log(
                "[FULL UPLOAD] musicId:", musicId,
                "musicStartTime:", musicStartTime,
                "musicEndTime:", musicEndTime,
                "videoStartTime:", videoStartTime,
                "videoEndTime:", videoEndTime,
            );

            if (!user || !req.files || !req.files.video) {
                return res.status(400).json({
                    success: false,
                    message: "User or video file missing!"
                });
            }

            let currentUsername = username || "";
            let currentName = name || "";

            try {
                let dbUser = null;

                if (userid && mongoose.isValidObjectId(userid)) {
                    dbUser = await User.findById(userid)
                        .select("username name")
                        .lean();
                }

                if (!dbUser) {
                    dbUser = await User.findOne({
                        $or: [{ userid: userid }, { userid: user }, { _id: user }],
                    })
                        .select("username name")
                        .lean();
                }

                if (dbUser && dbUser.username) {
                    currentUsername = dbUser.username;
                }

                if (dbUser && dbUser.name) {
                    currentName = dbUser.name;
                }
            } catch (err) {
                console.warn("⚠ Could not fetch latest username from DB:", err.message);
            }

            const videoFile = req.files.video[0];
            const thumbFile = req.files.thumbnail ? req.files.thumbnail[0] : null;

            const uploaderUserDoc = await User.findById(user)
                .select("seller_id userseller_id")
                .lean();

            let earlyThumbnailUrl = "";
            if (thumbFile?.buffer) {
                try {
                    earlyThumbnailUrl = await uploadToS3(
                        {
                            buffer: thumbFile.buffer,
                            originalname: `thumb-pending-${user}-${Date.now()}.jpg`,
                            mimetype: "image/jpeg",
                        },
                        "thumbnails"
                    ) || "";
                } catch (thumbErr) {
                    console.warn("[FULL UPLOAD] Early thumbnail upload failed:", thumbErr.message);
                }
            }

            const stubReel = new Reel({
                user,
                userid,
                username: currentUsername,
                name: currentName,
                caption,
                music: musicId && mongoose.Types.ObjectId.isValid(musicId) ? musicId : null,
                videoUrl: "",
                thumbnailUrl: earlyThumbnailUrl || "",
                status: "Processing",
                qualityVariants: [],
                seller_id: uploaderUserDoc?.seller_id || "",
                userseller_id: uploaderUserDoc?.userseller_id || "",
            });
            const savedStub = await stubReel.save();

            const jobData = {
                videoBuffer: videoFile.buffer,
                videoOriginalname: videoFile.originalname,
                thumbBuffer: thumbFile ? thumbFile.buffer : null,
                reelId: savedStub._id.toString(),
                user,
                userid,
                username: currentUsername,
                name: currentName,
                caption,
                musicId,
                videoStartTime,
                videoEndTime,
                musicStartTime,
                musicEndTime,
                externalAudioData: parsedAudioData,
            };

            processReelUpload(jobData).catch(err => {
                console.error("Worker failed after API responded:", err);
            });

            console.log("-> Job initiated. Responding with 202 Accepted.");
            return res.status(202).json({
                success: true,
                message: "Upload initiated. Video is being processed asynchronously.",
                status: "processing",
                reel: {
                    id: savedStub._id,
                    _id: savedStub._id,
                    status: savedStub.status,
                    caption: savedStub.caption,
                    thumbnailUrl: savedStub.thumbnailUrl,
                    qualityVariants: savedStub.qualityVariants || [],
                },
            });

        } catch (err) {
            console.error("===== [FULL UPLOAD API ERROR] =====");
            console.error(err);
            err.statusCode = err.statusCode || 500;
            await logError(req, err);
            res.status(500).json({
                success: false,
                message: "Server error during reel upload initiation.",
            });
        }
    }
);

router.post("/", upload.single("file"), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                message: "No file uploaded",
                success: false
            });
        }

        const folder = req.body.folder || "uploads";

        if (req.file.mimetype.startsWith("video/")) {
            const inputTmp = tmp.fileSync({ postfix: path.extname(req.file.originalname) });
            fs.writeFileSync(inputTmp.name, req.file.buffer);

            const outputTmp = tmp.fileSync({ postfix: ".mp4" });

            await compressVideo(inputTmp.name, outputTmp.name);

            const compressedBuffer = fs.readFileSync(outputTmp.name);

            const uploadedFileUrl = await uploadToS3(
                { buffer: compressedBuffer, originalname: "compressed-" + req.file.originalname, mimetype: "video/mp4" },
                folder
            );

            inputTmp.removeCallback();
            outputTmp.removeCallback();

            console.log("video", uploadedFileUrl)
            return res.status(200).json({
                message: "Video compressed & uploaded successfully!",
                success: true,
                file: uploadedFileUrl
            });

        } else {
            const uploadedFileUrl = await uploadToS3(req.file, folder);
            console.log("image", uploadedFileUrl)

            return res.status(200).json({
                message: "File uploaded successfully!",
                success: true,
                file: uploadedFileUrl
            });
        }

    } catch (error) {
        console.error("Error on file upload:", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({
            message: "Error on file upload!",
            success: false
        });
    }
});

router.post("/upload", async (req, res) => {
    try {
        const data = await req.body;

        if (!data.user || !data.videoUrl) {
            res.status(400).json({ message: "User ID or Video Url missing!" });
        }

        const newReel = new Reel(
            data
        );

        const savedReel = await newReel.save();

        try {
            const uploaderUser = await User.findById(savedReel.user);
            if (uploaderUser && savedReel.userid) {
                const { slug, shortLink } = generateShortLink(savedReel._id, savedReel.userid);
                savedReel.shortLinks.push({
                    slug,
                    shortLink,
                    generatedForUser: uploaderUser._id,
                    generatedAt: new Date()
                });
                await savedReel.save();
                console.log(`Short link generated and saved for reel ${savedReel._id}: ${shortLink}`);
            }
        } catch (shortLinkError) {
            console.warn("Failed to generate short link (non-blocking):", shortLinkError.message);
        }

        if (typeof savedReel.videoUrl === "string" && savedReel.videoUrl.toLowerCase().includes(".mp4")) {
            await Reel.findByIdAndUpdate(savedReel._id, { status: "Processing" });
            convertMp4UrlToHlsAndUpdateReel(savedReel._id, savedReel.videoUrl).catch(() => { });
            return res.status(202).json({
                message: "Reel saved. Video is being optimized for streaming.",
                data: { id: savedReel._id, savedReel }
            });
        }

        try {
            await logUserAction({
                user: savedReel.user,
                action: "upload_reel",
                targetType: "Reel",
                targetId: savedReel._id,
                device: req.headers["user-agent"],
                location: {
                    ip: req.headers["x-forwarded-for"] || req.socket.remoteAddress || "",
                    country: req.headers["cf-ipcountry"] || "",
                    city: "", 
                    pincode: ""
                }
            });
        } catch (logError) {
            console.error("Log error (non-blocking):", logError.message);
        }
        res.status(201).json({
            message: "Reels Saved Successfully",
            data: {
                id: savedReel._id,
                savedReel
            }
        });

    } catch (error) {
        res.status(500).json({ message: "An Error occure in Upload Reel!" });
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        console.log("Error in upload reel", error);
    }
});

router.get("/by-music/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const currentUserId = req.query.currentUserId || req.query.viewerId; // Frontend se viewerId ya currentUserId bhej dena

        // 1️⃣ Validate music id
        if (!id || id === "null" || id === "undefined") {
            return res.status(400).json({
                message: "Valid Music ID is required"
            });
        }

        let query = {
            music: id,
            status: { $ne: "Blocked" }   // 👈 IMPORTANT LINE
        };

        // 🔥 ADDED: MUTUAL BLOCK FILTER LOGIC START 🔥
        if (currentUserId && mongoose.isValidObjectId(currentUserId)) {
            const viewer = await User.findById(currentUserId).select("blockedUsers").lean();
            const blockedList = viewer?.blockedUsers || [];
            
            const blockers = await User.find({ blockedUsers: currentUserId }).select("_id").lean();
            const usersWhoBlockedMe = blockers.map(b => b._id);
            
            const allBlocked = [...blockedList, ...usersWhoBlockedMe];

            if (allBlocked.length > 0) {
                query.user = { $nin: allBlocked }; // Blocked logo ki reels music list se hide
            }
        }
        // 🔥 ADDED: MUTUAL BLOCK FILTER LOGIC END 🔥

        // 2️⃣ Find reels using this music
        const reels = await Reel.find(query)
            .populate("music")                 // music details
            .populate("user", "username")      // reel owner username
            .populate("comments");             // comments

        // 3️⃣ No reels found
        if (!reels || reels.length === 0) {
            return res.status(404).json({
                message: "No reels found for this music"
            });
        }

        // 4️⃣ Success response
        return res.status(200).json({
            message: "Reels fetched successfully",
            data: reels
        });

    } catch (error) {
        console.error("Error fetching reels by music:", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        return res.status(500).json({
            message: "Error fetching reels",
            error: error.message
        });
    }
});


router.get(
  "/",
 
  async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 8;
      const search = req.query.search || "";
      const status = req.query.status || "all";
      const startDate = req.query.startDate || "";
      const endDate = req.query.endDate || "";

      const skip = (page - 1) * limit;

      // ✅ BUILD QUERY
      const query = {};

      // 🔍 SEARCH FILTER
      if (search) {
        query.$or = [
    { caption: { $regex: search, $options: "i" } },
    { username: { $regex: search, $options: "i" } }
  ];
      }

      // 🎯 STATUS FILTER
      if (status !== "all") {
        query.status = status;
      }

      // 📅 DATE RANGE FILTER
      if (startDate || endDate) {
        query.createdAt = {};

        if (startDate) {
          query.createdAt.$gte = new Date(startDate);
        }

        if (endDate) {
          const end = new Date(endDate);
          end.setHours(23, 59, 59, 999); // full end day include
          query.createdAt.$lte = end;
        }
      }

      // ✅ TOTAL COUNT (WITH FILTER)
      const total = await Reel.countDocuments(query);

      // ✅ FETCH DATA
      const reels = await Reel.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);

      res.status(200).json({
        data: reels,
        total: total,
        page,
        limit,
      });

    } catch (error) {
      console.error("Error fetching reels:", error);
      error.statusCode = error.statusCode || 500;
      await logError(req, error);
      res.status(500).json({
        message: "Error fetching reels",
      });
    }
  }
);

router.get(
  "/admin_reels",
  adminAuth,
  checkPermission("VIEW_REELS"),
  async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 8;
      const search = req.query.search || "";
      const status = req.query.status || "all";
      const startDate = req.query.startDate || "";
      const endDate = req.query.endDate || "";

      const skip = (page - 1) * limit;

      // ✅ BUILD QUERY
      const query = {};

      // 🔥 1. DEFAULT FILTER: Hamesha Deleted Users ki reels hide karo
      // Iske liye ab frontend se 'activeUsersOnly' bhejne ki zaroorat nahi hai.
      const activeUsers = await User.find({ isDeleted: { $ne: true } }).select("_id");
      const activeUserIds = activeUsers.map(user => user._id);
      
      // Reel sirf active users ki hi aayegi
      query.user = { $in: activeUserIds };

      // 🔥 2. DEFAULT FILTER: Hamesha Soft Deleted Reels ko hide karo
      // Agar aap status explicitly "deleted" bhejte ho tabhi dikhega
      if (status === "deleted") {
        query.isDeleted = true;
      } else {
        query.isDeleted = { $ne: true }; 
      }

      // 🔍 3. SEARCH FILTER
      if (search) {
        query.$or = [
          { caption: { $regex: search, $options: "i" } },
          { username: { $regex: search, $options: "i" } }
        ];
      }

      // 🎯 4. STATUS FILTER (Agar status 'deleted' ya 'all' ke alawa kuch aur hai jaise 'active')
      if (status !== "all" && status !== "deleted") {
        query.status = status;
      }

      // 📅 5. DATE RANGE FILTER
      if (startDate || endDate) {
        query.createdAt = {};

        if (startDate) {
          query.createdAt.$gte = new Date(startDate);
        }

        if (endDate) {
          const end = new Date(endDate);
          end.setHours(23, 59, 59, 999); // full end day include
          query.createdAt.$lte = end;
        }
      }

      // ✅ TOTAL COUNT (WITH FILTER)
      const total = await Reel.countDocuments(query);

      // ✅ FETCH DATA
      const reels = await Reel.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);

      res.status(200).json({
        data: reels,
        total: total,
        page,
        limit,
      });

    } catch (error) {
      console.error("Error fetching reels:", error);
      error.statusCode = error.statusCode || 500;
      await logError(req, error);
      res.status(500).json({
        message: "Error fetching reels",
      });
    }
  }
);

router.get("/shownew", async (req, res) => { 
    try {
        const limit = parseInt(req.query.limit || "2", 10);
        // Exclude logic as it is
        const exclude = req.query.exclude?.split(",").filter(Boolean) || [];
        const currentUserId = req.query.userId;
        const direction = req.query.direction || "next";

        if (!currentUserId) {
            return res.status(400).json({ message: "Missing userId" });
        }

        let matchStage = exclude.length
            ? { _id: { $nin: exclude.map((id) => new mongoose.Types.ObjectId(id)) } }
            : {};

        matchStage.isDeleted = { $ne: true };
        matchStage.status = { $ne: "Blocked" };

        if (mongoose.isValidObjectId(currentUserId)) {
            const viewer = await User.findById(currentUserId).select("blockedUsers isDeleted").lean();
            
            if (viewer && viewer.isDeleted) {
                return res.status(403).json({ message: "Your account is deleted. Access denied." });
            }

            const blockedList = viewer?.blockedUsers || [];
            const blockers = await User.find({ blockedUsers: currentUserId }).select("_id").lean();
            const usersWhoBlockedMe = blockers.map(b => b._id);
            
            const allExcludedUsers = [...blockedList, ...usersWhoBlockedMe];
            if (allExcludedUsers.length > 0) {
                matchStage.user = { $nin: allExcludedUsers }; 
            }

            const notInterestedInteractions = await ReelInteraction.find({
                user: currentUserId,
                action: "not_interested"
            })
            .select("reel")
            .sort({ createdAt: -1 })
            .limit(200) 
            .lean();

            if (notInterestedInteractions.length > 0) {
                const notInterestedReelIds = notInterestedInteractions.map(interaction => interaction.reel);
                if (matchStage._id && matchStage._id.$nin) {
                    matchStage._id.$nin.push(...notInterestedReelIds);
                } else {
                    matchStage._id = { $nin: notInterestedReelIds };
                }
            }
        }

        // 🎬 Sample random reels (Bina $lookup ke)
        const reels = await Reel.aggregate([
            { $match: matchStage },
            { $sample: { size: limit } }
        ]);

        // 🔥 NAYA FIX: Mongoose Populate (Fast aur Bulletproof) 🔥
        // Yeh sirf ek query me saare reel owners ka data le aayega bina strict format mismatch ke
        await User.populate(reels, { 
            path: "user", 
            select: "profilePicture followers seller_id userseller_id" 
        });

        // 👤 Fetch current user's profile picture
        const currentUser = await User.findById(currentUserId, "profilePicture").lean();
        const currentUserProfilePic = currentUser?.profilePicture || "";
        const currentUserIdStr = currentUserId.toString();

        // 🔁 Map Loop
        const reelsWithFollow = reels.map((reel) => {
            // Populate hone ke baad `reel.user` ab ek puri object ban chuka hai
            const owner = (reel.user && reel.user._id) ? reel.user : {};
            
            // Followers check karo
            let isFollowing = false;
            if (owner.followers && Array.isArray(owner.followers)) {
                isFollowing = owner.followers.some(followerId => followerId.toString() === currentUserIdStr);
            }

            return {
                ...reel, 
                // Frontend ko ID ki aadat hai, toh object hata kar wapas string ID set kar di
                user: owner._id ? owner._id.toString() : reel.user, 
                isFollowing: isFollowing,
                currentUserProfilePic,
                reelUserProfilePic: owner.profilePicture || "", // 👈 Photo ab yahan se 100% milegi
                seller_id: reel.seller_id || owner.seller_id || "",
                userseller_id: reel.userseller_id || owner.userseller_id || "",
            };
        });

        res.json({ reels: reelsWithFollow, direction });
    } catch (e) {
        console.error("Error fetching reels:", e);
        e.statusCode = e.statusCode || 500;
        res.status(500).json({ message: "Error fetching reels" });
    }
});

router.post("/view", async (req, res) => {
    try {
        const { reelId, userId } = req.body;

        if (!reelId || !userId) {
            return res.status(400).json({ message: "reelId and userId are required" });
        }

        if (!mongoose.isValidObjectId(reelId) || !mongoose.isValidObjectId(userId)) {
            return res.status(400).json({ message: "Invalid reelId or userId" });
        }

        // Fetch user with blockedUsers for block check
        const user = await User.findById(userId).select("isSuspended blockedUsers").lean();

        if (user?.isSuspended) {
            return res.status(200).json({
                message: "View ignored"
            });
        }

        // 🔥 ADDED: MUTUAL BLOCK CHECK START 🔥
        const currentReel = await Reel.findById(reelId).select("user").lean();
        if (!currentReel) {
            return res.status(404).json({ message: "Reel not found" });
        }

        if (currentReel.user) {
            const owner = await User.findById(currentReel.user).select("blockedUsers").lean();

            const hasOwnerBlockedViewer = owner?.blockedUsers?.some(bid => bid.toString() === userId.toString());
            const hasViewerBlockedOwner = user?.blockedUsers?.some(bid => bid.toString() === currentReel.user.toString());

            if (hasOwnerBlockedViewer || hasViewerBlockedOwner) {
                // View ko silently ignore kar diya taaki frontend player crash na ho
                return res.status(200).json({ message: "View ignored due to privacy" }); 
            }
        }
        // 🔥 ADDED: MUTUAL BLOCK CHECK END 🔥

        // Atomically add user to viewsdata only if not present, and increment views only in that case
        const updated = await Reel.findOneAndUpdate(
            { _id: reelId, viewsdata: { $ne: userId } },
            { $addToSet: { viewsdata: userId }, $inc: { views: 1 } },
            { new: true }
        );

        if (!updated) {
            // Either reel not found, or user already counted (can't distinguish without another query)
            const reelExists = await Reel.exists({ _id: reelId });
            if (!reelExists) return res.status(404).json({ message: "Reel not found" });
            return res.status(200).json({ message: "View already counted" });
        }

        return res.status(200).json({
            message: "View added",
            views: updated.views,
        });
    } catch (error) {
        console.error("Error incrementing reel view:", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({ message: "Error incrementing reel view" });
    }
});

router.get("/current/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const { currentUserId } = req.query; // current logged-in user

        // 1️⃣ Validate Reel ID
        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({ message: "Invalid reel ID" });
        }

        // 2️⃣ Fetch reel
        const currentReel = await Reel.findById(id).lean();
        if (!currentReel) {
            return res.status(404).json({ message: "Reel not found!" });
        }

        // 🔥 3️⃣ BLOCK CHECK (MOST IMPORTANT)
        if (currentReel.status === "Blocked") {
            return res.status(404).json({ message: "Reel not available" });
        }

        // 🔥 ADDED: MUTUAL BLOCK CHECK START 🔥
        if (currentUserId && mongoose.isValidObjectId(currentUserId) && currentReel.user) {
            const viewer = await User.findById(currentUserId).select("blockedUsers").lean();
            const owner = await User.findById(currentReel.user).select("blockedUsers").lean();

            const hasViewerBlockedOwner = viewer?.blockedUsers?.some(bid => bid.toString() === currentReel.user.toString());
            const hasOwnerBlockedViewer = owner?.blockedUsers?.some(bid => bid.toString() === currentUserId.toString());

            if (hasViewerBlockedOwner || hasOwnerBlockedViewer) {
                return res.status(404).json({ message: "Reel not available" });
            }
        }
        // 🔥 ADDED: MUTUAL BLOCK CHECK END 🔥

        // 4️⃣ Fetch current user's profile picture
        let currentUserProfilePic = "";
        if (currentUserId && mongoose.isValidObjectId(currentUserId)) {
            const currentUser = await User.findById(
                currentUserId,
                "profilePicture"
            ).lean();
            currentUserProfilePic = currentUser?.profilePicture || "";
        }

        // 5️⃣ Fetch reel owner info
        const reelOwner = await User.findById(
            currentReel.user,
            "profilePicture followers"
        ).lean();

        const reelUserProfilePic = reelOwner?.profilePicture || "";

        // 6️⃣ Check follow status
        const isFollowing = reelOwner?.followers?.some(
            (followerId) => followerId.toString() === currentUserId
        );

        // 7️⃣ Final response object
        const reelWithProfiles = {
            ...currentReel,
            reelUserProfilePic,
            currentUserProfilePic,
            isFollowing: !!isFollowing,
        };

        // 8️⃣ Send response
        res.status(200).json(reelWithProfiles);

    } catch (error) {
        console.error("Error in /current/:id →", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({ message: "Server error" });
    }
});

router.get("/admin_current/:id", adminAuth, async (req, res) => {
    try {
        const { id } = req.params;
        const { currentUserId } = req.query; // current logged-in user

        // 1️⃣ Validate Reel ID
        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({ message: "Invalid reel ID" });
        }

        // 2️⃣ Fetch reel
        const currentReel = await Reel.findById(id).lean();
        if (!currentReel) {
            return res.status(404).json({ message: "Reel not found!" });
        }

        // 🔥 3️⃣ BLOCK CHECK (MOST IMPORTANT)
        if (currentReel.status === "Blocked") {
            return res.status(404).json({ message: "Reel not available" });
        }

        // 4️⃣ Fetch current user's profile picture
        let currentUserProfilePic = "";
        if (currentUserId && mongoose.isValidObjectId(currentUserId)) {
            const currentUser = await User.findById(
                currentUserId,
                "profilePicture"
            ).lean();
            currentUserProfilePic = currentUser?.profilePicture || "";
        }

        // 5️⃣ Fetch reel owner info
        const reelOwner = await User.findById(
            currentReel.user,
            "profilePicture followers"
        ).lean();

        const reelUserProfilePic = reelOwner?.profilePicture || "";

        // 6️⃣ Check follow status
        const isFollowing = reelOwner?.followers?.some(
            (followerId) => followerId.toString() === currentUserId
        );

        // 7️⃣ Final response object
        const reelWithProfiles = {
            ...currentReel,
            reelUserProfilePic,
            currentUserProfilePic,
            isFollowing: !!isFollowing,
        };

        // 8️⃣ Send response
        res.status(200).json(reelWithProfiles);

    } catch (error) {
        console.error("Error in /current/:id →", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({ message: "Server error" });
    }
});

// Get other reels
router.get("/others/:userId", async (req, res) => {
    try {
        const { userId } = req.params;
        const {
            limit = 10,
            skip = 0,
            excludeId,
            reelType,
            currentUserId,
            musicId,
            playableOnly,
        } = req.query;

        const onlyPlayable =
            playableOnly === "1" ||
            playableOnly === "true" ||
            playableOnly === true;

        let query = {};

        // 🔥 BLOCKED REELS HIDE (USER SIDE)
        query.status = onlyPlayable ? "Published" : { $ne: "Blocked" };

        if (onlyPlayable) {
            query.videoUrl = { $exists: true, $nin: ["", null] };
            // 480p goes live first; 720p is added in the background.
            query.qualityVariants = { $in: ["480p", "720p"] };
        }

        // 🎯 Decide which reels to fetch
        if (reelType === "liked") {
            if (!currentUserId) {
                return res.status(400).json({
                    message: "currentUserId is required for liked reels"
                });
            }
            query.likes = currentUserId;

        } else if (reelType === "music") {
            if (!musicId) {
                return res.status(400).json({
                    message: "musicId is required for music reels"
                });
            }
            query.music = musicId;

        } else {
            query.user = userId;
        }

        // 🔥 ADDED: MUTUAL BLOCK FILTER LOGIC START 🔥
        if (currentUserId && mongoose.isValidObjectId(currentUserId)) {
            const viewer = await User.findById(currentUserId).select("blockedUsers").lean();
            const blockedList = viewer?.blockedUsers || [];
            
            const blockers = await User.find({ blockedUsers: currentUserId }).select("_id").lean();
            const usersWhoBlockedMe = blockers.map(b => b._id);
            
            const allBlocked = [...blockedList, ...usersWhoBlockedMe];

            if (allBlocked.length > 0) {
                if (query.user) {
                    // Agar specific profile dekh rahe hain, aur wo block hai, toh seedha empty return
                    const isBlocked = allBlocked.some(bid => bid.toString() === query.user.toString());
                    if (isBlocked) {
                        return res.status(200).json([]); 
                    }
                } else {
                    // Agar Liked ya Music reels dekh rahe hain, toh blocked owners ki reels nikal do
                    query.user = { $nin: allBlocked };
                }
            }
        }
        // 🔥 ADDED: MUTUAL BLOCK FILTER LOGIC END 🔥

        if (currentUserId && mongoose.isValidObjectId(currentUserId)) {
    const notInterested = await ReelInteraction.find({
        user: new mongoose.Types.ObjectId(currentUserId),
        action: "not_interested"
    }).select("reel").lean();

    if (notInterested.length > 0) {
        const notInterestedIds = notInterested.map(
            i => new mongoose.Types.ObjectId(i.reel)
        );

        if (query._id) {
            query._id = {
                ...query._id,
                $nin: [...(query._id.$nin || []), ...notInterestedIds]
            };
        } else {
            query._id = { $nin: notInterestedIds };
        }
    }
}

      // 🚫 Exclude a reel (for infinite scroll) — FIXED
if (excludeId) {
    const excludeObjectId = new mongoose.Types.ObjectId(excludeId);

    if (query._id) {
        query._id = {
            ...query._id,
            $ne: excludeObjectId
        };
    } else {
        query._id = { $ne: excludeObjectId };
    }
}

        // 📦 Fetch reels
        const reels = await Reel.find(query)
            .sort({ createdAt: -1 })
            .skip(parseInt(skip))
            .limit(parseInt(limit))
            .lean();

        if (!reels.length) {
            return res.status(200).json([]);
        }

        // 👤 Fetch current user's profile picture
        let currentUserProfilePic = "";
        if (currentUserId && mongoose.isValidObjectId(currentUserId)) {
            const currentUser = await User.findById(
                currentUserId,
                "profilePicture"
            ).lean();
            currentUserProfilePic = currentUser?.profilePicture || "";
        }

        // 🔁 Enhance reels with follow status + profile pics
        const enhancedReels = await Promise.all(
            reels.map(async (reel) => {
                const reelOwner = await User.findById(
                    reel.user,
                    "profilePicture followers"
                ).lean();

                const reelUserProfilePic = reelOwner?.profilePicture || "";

                const isFollowing = reelOwner?.followers?.some(
                    (followerId) =>
                        followerId.toString() === currentUserId
                );

                return {
                    ...reel,
                    reelUserProfilePic,
                    currentUserProfilePic,
                    isFollowing: !!isFollowing,
                };
            })
        );

        res.status(200).json(enhancedReels);

    } catch (error) {
        console.error(error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({ message: "Server error" });
    }
});


//delete video
router.delete("/delete/:reelId/:userid", async (req, res) => {
    try {
        const { reelId, userid } = req.params;

        // 1️⃣ Validate reelId
        if (!mongoose.isValidObjectId(reelId)) {
            return res.status(400).json({ message: "Invalid reel id" });
        }

        // 2️⃣ Find reel
        const reel = await Reel.findById(reelId);
        if (!reel) {
            return res.status(404).json({ message: "Reel not found" });
        }

        // 3️⃣ OWNER CHECK (✅ FIXED: Using reel.user and .toString() to match your test URL)
        if (reel.user.toString() !== userid) {
            return res.status(403).json({
                message: "You are not allowed to delete this reel"
            });
        }

        // 4️⃣ LOG (✅ ObjectId)
        try {
            await logUserAction({
                user: req.user._id, // Assumes you have auth middleware setting req.user
                userName: req.userName,
                userRole: req.userRole,
                action: "delete_reel",
                targetType: "Reel",
                targetId: reelId,
                targetName: `Reel ID: ${reelId}`,
                device: req.headers["user-agent"],
                location: {
                    ip:
                        req.headers["x-forwarded-for"] ||
                        req.socket.remoteAddress ||
                        "",
                    country: req.headers["cf-ipcountry"] || "",
                }
            });
        } catch (e) {
            console.error("Log error:", e.message);
        }

        // 5️⃣ Delete comments
        await Comment.deleteMany({ reel: reelId });

        // 6️⃣ Delete reel
        await reel.deleteOne();

        return res.status(200).json({
            success: true,
            message: "Reel + comments + likes + views deleted successfully"
        });

    } catch (error) {
        console.error("Delete reel error:", error);
        // Fallback status code if error.statusCode is undefined
        const statusCode = error.statusCode || 500; 
        
        // Log error if the function exists
        if (typeof logError === 'function') {
            await logError(req, error);
        }
        
        return res.status(statusCode).json({ message: "Error deleting reel" });
    }
});

router.delete("/admin_delete/:reelId/:userid",adminAuth,
    checkPermission("DELETE_REEL"), async (req, res) => {
        try {
            const { reelId, userid } = req.params;

            // 1️⃣ Validate reelId
            if (!mongoose.isValidObjectId(reelId)) {
                return res.status(400).json({ message: "Invalid reel id" });
            }

            // 2️⃣ Find reel
            const reel = await Reel.findById(reelId);
            if (!reel) {
                return res.status(404).json({ message: "Reel not found" });
            }

            // 3️⃣ OWNER CHECK (string based)
            if (reel.userid !== userid) {
                return res.status(403).json({
                    message: "You are not allowed to delete this reel"
                });
            }

            // 4️⃣ LOG (✅ ObjectId)
            try {
                await logUserAction({
                    user: req.user._id,
                    userName: req.userName,
                    userRole: req.userRole,
                    action: "delete_reel",
                    targetType: "Reel",
                    targetId: reelId,
                    targetName: `Reel ID: ${reelId}`,
                    device: req.headers["user-agent"],
                    location: {
                        ip:
                            req.headers["x-forwarded-for"] ||
                            req.socket.remoteAddress ||
                            "",
                        country: req.headers["cf-ipcountry"] || "",
                    }
                });
            } catch (e) {
                console.error("Log error:", e.message);
            }

            // 5️⃣ Delete comments
            await Comment.deleteMany({ reel: reelId });

            // 6️⃣ Delete reel
            await reel.deleteOne();

            return res.status(200).json({
                success: true,
                message: "Reel + comments + likes + views deleted successfully"
            });

        } catch (error) {
            error.statusCode = error.statusCode || 500;
            console.error("Delete reel error:", error);
            await logError(req, error);
            return res.status(500).json({ message: "Error deleting reel" });
        }
    });

router.put("/update/:id", async (req, res) => {
    try {
        const { videoUrl, thumbnailUrl, caption, duration, music } = await req.body;
        const video = await Reel.findById(req.params.id);
        if (!video) { res.status(404).json({ message: "Video not found!" }) };
        if (videoUrl) { video.videoUrl = videoUrl };
        if (thumbnailUrl) { video.thumbnailUrl = thumbnailUrl };
        if (caption) { video.caption = caption };
        if (duration) { video.duration = duration };
        if (music) { video.music = music };

        const updatedReel = await video.save();


        // Safely log user action (even if log fails, app continues)
        try {
            await logUserAction({
                user: video.user,
                action: "update_reel",
                targetType: "Reel",
                targetId: req.params.id,
                device: req.headers["user-agent"],
                location: {
                    ip: req.headers["x-forwarded-for"] || req.socket.remoteAddress || "",
                    country: req.headers["cf-ipcountry"] || "",
                    city: "", // Optional: Use IP geolocation later
                    pincode: ""
                }
            });
        } catch (logError) {
            console.error("Log error (non-blocking):", logError.message);
        }
        res.status(200).json({
            _id: updatedReel._id,
            videoUrl: updatedReel.videoUrl,
            thumbnailUrl: updatedReel.thumbnailUrl,
            caption: updatedReel.caption,
            duration: updatedReel.duration,
            music: updatedReel.music,
        });


    } catch (error) {
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({
            message: "Error in updation!"
        });
        console.log("Error in updateion reel", error);
    }
});

// Like or Unlike a Reel
router.put("/like/:id", async (req, res) => {
    try {
        const { userId } = req.body; // who is liking
        const reelId = req.params.id;

        if (!userId) return res.status(400).json({ message: "User ID is required" });

        // ✅ Fetch user
        const user = await User.findById(userId);
        if (!user) return res.status(404).json({ message: "User not found" });
        if (!user.userid) return res.status(500).json({ message: "User.userid missing" });

        if (user.isSuspended) {
            // user reel dekh sakta hai, but like/unlike count nahi badhega
            return res.status(200).json({
                message: "Like ignored"
            });
        }

        // ✅ Fetch reel
        const reel = await Reel.findById(reelId);
        if (!reel) return res.status(404).json({ message: "Reel not found" });
        if (!reel.userid) return res.status(500).json({ message: "Reel.userid missing" });

        // 🔥 ADDED: MUTUAL BLOCK CHECK START 🔥
        if (reel.user) {
            const owner = await User.findById(reel.user).select("blockedUsers").lean();
            
            const hasOwnerBlockedViewer = owner?.blockedUsers?.some(bid => bid.toString() === userId.toString());
            const hasViewerBlockedOwner = user.blockedUsers?.some(bid => bid.toString() === reel.user.toString());

            if (hasOwnerBlockedViewer || hasViewerBlockedOwner) {
                return res.status(403).json({ message: "Action not allowed due to privacy settings." });
            }
        }
        // 🔥 ADDED: MUTUAL BLOCK CHECK END 🔥

        const alreadyLiked = reel.likes.includes(userId);

        if (alreadyLiked) {
            // ❌ UNLIKE (NO NOTIFICATION)
            reel.likes = reel.likes.filter(id => id.toString() !== userId);
            await reel.save();

            return res.status(200).json({
                message: "Reel unliked",
                likes: reel.likes.length
            });

        } else {
            // ❤️ LIKE
            reel.likes.push(userId);
            await reel.save();

            // 🔔 CREATE LIKE NOTIFICATION
            try {
                console.log("Creating like notification:", {
                    recipientUserId: reel.userid,
                    senderUserId: user.userid,
                    type: "like",
                    reel: reelId
                });

                await createNotification({
                    recipientObjectId: reel.user,   // Mongo ObjectId of reel owner
                    senderObjectId: user._id,       // Mongo ObjectId of liker
                    recipientUserId: reel.userid,   // userid string
                    senderUserId: user.userid,      // userid string
                    type: "like",
                    reel: reelId,
                    message: "liked your reel"
                });

            } catch (notifError) {
                console.error("Like notification failed:", notifError.message);
            }

            return res.status(200).json({
                message: "Reel liked",
                likes: reel.likes.length
            });
        }

    } catch (error) {
        console.error("Error in liking/unliking reel:", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({ message: "Something went wrong" });
    }
});

// return total likes of all users
router.get("/totallikes",adminAuth ,  async (req, res) => {
    try {
        // Sirf likes field uthao (fast)
        const reels = await Reel.find({}, "likes");

        let totalLikes = 0;

        for (const reel of reels) {
            totalLikes += reel.likes.length;
        }

        res.status(200).json({
            totalLikes, // 👈 ALL USERS TOTAL LIKES
        });
    } catch (error) {
        console.error("Error fetching total likes:", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({ message: "Server error" });
    }
});

// return this api total views of all users
router.get("/totalviews",adminAuth ,  async (req, res) => {
    try {
        // Sirf views field uthao (fast query)
        const reels = await Reel.find({}, "views");

        let totalViews = 0;

        for (const reel of reels) {
            totalViews += reel.views || 0;
        }

        res.status(200).json({
            totalViews, // 👈 ALL USERS TOTAL VIEWS
        });
    } catch (error) {
        console.error("Error fetching total views:", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        res.status(500).json({ message: "Server error" });
    }
});


router.put("/block/:id",   async (req, res) => {
        try {
            const { id } = req.params;
            const { action, reason } = req.body;
            // action = "block" | "unblock"

            if (!mongoose.isValidObjectId(id)) {
                return res.status(400).json({ message: "Invalid reel id" });
            }

            if (!["block", "unblock"].includes(action)) {
                return res.status(400).json({ message: "Invalid action" });
            }

            let updateData = {};

            if (action === "block") {
                updateData = {
                    status: "Blocked",
                    blockedAt: new Date(),                 // ✅ auto time
                    blockReason: reason || "Policy violation"
                };
            } else {
                updateData = {
                    status: "Published",
                    blockedAt: null,                       // ✅ reset
                    blockReason: null
                };
            }

            const reel = await Reel.findByIdAndUpdate(
                id,
                updateData,
                { new: true }
            );
            try {
                await logUserAction({
                    user: req.user._id,
                    userName: req.userName,
                    userRole: req.userRole,

                    action: action === "block" ? "block_reel" : "unblock_reel",

                    targetType: "Reel",
                    targetId: reel._id,
                    targetName: `Reel ID: ${reel._id}`,
                    device: req.headers["user-agent"],
                    location: {
                        ip:
                            req.headers["x-forwarded-for"] ||
                            req.socket.remoteAddress ||
                            "",
                        country: req.headers["cf-ipcountry"] || "",
                    },
                });
            } catch (e) {
                console.error("Log error:", e.message);
            }
            if (!reel) {
                return res.status(404).json({ message: "Reel not found" });
            }

            return res.status(200).json({
                success: true,
                message: `Reel ${action === "block" ? "blocked" : "unblocked"} successfully`,
                reel
            });

        } catch (error) {
            console.error("Error blocking/unblocking reel:", error);
            error.statusCode = error.statusCode || 500;
            await logError(req, error);
            res.status(500).json({ message: "Server error" });
        }
    });


 router.put("/admin_block/:id", adminAuth,
    checkPermission("BLOCK_REEL"), async (req, res) => {
        try {
            const { id } = req.params;
            const { action, reason } = req.body;
            // action = "block" | "unblock"

            if (!mongoose.isValidObjectId(id)) {
                return res.status(400).json({ message: "Invalid reel id" });
            }

            if (!["block", "unblock"].includes(action)) {
                return res.status(400).json({ message: "Invalid action" });
            }

            let updateData = {};

            if (action === "block") {
                updateData = {
                    status: "Blocked",
                    blockedAt: new Date(),                 // ✅ auto time
                    blockReason: reason || "Policy violation"
                };
            } else {
                updateData = {
                    status: "Published",
                    blockedAt: null,                       // ✅ reset
                    blockReason: null
                };
            }

            const reel = await Reel.findByIdAndUpdate(
                id,
                updateData,
                { new: true }
            );
            try {
                await logUserAction({
                    user: req.user._id,
                    userName: req.userName,
                    userRole: req.userRole,

                    action: action === "block" ? "block_reel" : "unblock_reel",

                    targetType: "Reel",
                    targetId: reel._id,
                    targetName: `Reel ID: ${reel._id}`,
                    device: req.headers["user-agent"],
                    location: {
                        ip:
                            req.headers["x-forwarded-for"] ||
                            req.socket.remoteAddress ||
                            "",
                        country: req.headers["cf-ipcountry"] || "",
                    },
                });
            } catch (e) {
                console.error("Log error:", e.message);
            }
            if (!reel) {
                return res.status(404).json({ message: "Reel not found" });
            }

            return res.status(200).json({
                success: true,
                message: `Reel ${action === "block" ? "blocked" : "unblocked"} successfully`,
                reel
            });

        } catch (error) {
            console.error("Error blocking/unblocking reel:", error);
            error.statusCode = error.statusCode || 500;
            await logError(req, error);
            res.status(500).json({ message: "Server error" });
        }
    });

router.get("/admin/users/:userid/liked-reels", adminAuth ,  async (req, res) => {
    try {
        const { userid } = req.params;

        // pagination params
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 8;
        const skip = (page - 1) * limit;

        // 1️⃣ Find the user admin clicked
        const user = await User.findOne({ userid });
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // 2️⃣ Count total liked reels
        const total = await Reel.countDocuments({
            likes: user._id,
        });

        // 3️⃣ Fetch paginated liked reels
        const reels = await Reel.find({
            likes: user._id,
        })
            .populate("user", "userid username profilePicture")
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit);

        return res.json({
            success: true,
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit),
            hasMore: skip + reels.length < total,
            reels,
        });
    } catch (error) {
        console.error("Error fetching liked reels:", error);
        error.statusCode = error.statusCode || 500;
        await logError(req, error);
        return res.status(500).json({ message: "Server error" });
    }
});


router.get("/users/:userId/music", adminAuth , async (req, res) => {
    try {
        const { userId } = req.params;
        const page = Number(req.query.page) || 1;
        const limit = 8;
        const skip = (page - 1) * limit;

        // safety check
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: "Invalid userId" });
        }

        const totalItems = await Music.countDocuments({
            uploadedBy: userId
        });

        const music = await Music.find({
            uploadedBy: userId
        })
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit);

        res.json({
            music,
            pagination: {
                totalItems,
                currentPage: page,
                totalPages: Math.ceil(totalItems / limit),
                limit
            }
        });
    } catch (err) {
        console.error("Fetch user music error:", err);
        err.statusCode = err.statusCode || 500;
        await logError(req, err);
        res.status(500).json({ message: "Failed to fetch user music" });
    }
});

module.exports = router;