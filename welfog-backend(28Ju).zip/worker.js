const mongoose = require('mongoose');
const fs = require("fs");
const path = require("path");
const tmp = require("tmp");
const http = require("http");
const https = require("https");
const os = require("os");
const ffmpeg = require("fluent-ffmpeg");
const ffmpegInstaller = require("@ffmpeg-installer/ffmpeg");
const ffprobeStatic = require('ffprobe-static');
const { Worker } = require('bullmq');
const IORedis = require('ioredis');
require('dotenv').config();

// AWS SDK import for deleting raw file
const { DeleteObjectCommand } = require("@aws-sdk/client-s3");

// Apne DB models require karo
const Reel = require("./models/Reel"); 
const User = require("./models/Users");
const Music = require("./models/Music"); 
const { uploadToS3, s3 } = require("./lib/s3"); // S3 client aur upload function
const { generateShortLink } = require("./utils/shortLink");

// DB Connection
console.log("🔄 Trying to connect to MongoDB...");
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log("✅ Worker connected to MongoDB"))
    .catch(err => console.error("❌ Worker DB Connection Error:", err));

ffmpeg.setFfmpegPath(ffmpegInstaller.path);
ffmpeg.setFfprobePath(ffprobeStatic.path);
console.log("🎬 FFmpeg paths configured successfully.");

// =================================================================
// === FFMPEG & DOWNLOAD HELPERS ===
// =================================================================
async function compressVideo(inputPath, outputPath) {
    console.log(`🎬 [compressVideo] Started for ${inputPath}`);
    const metadata = await new Promise((resolve, reject) => {
        ffmpeg.ffprobe(inputPath, (err, data) => { if (err) return reject(err); resolve(data); });
    });
    const video = metadata.streams.find(s => s.codec_type === "video");
    const width = video.width; const height = video.height;
    const duration = parseFloat(video.duration);
    const originalSizeMB = (fs.statSync(inputPath).size / (1024 * 1024));
    let crf, bps, scaleFilter;
    if (duration >= 60 && duration <= 180) {
        if (originalSizeMB <= 40) { crf = 23; bps = 1100; }
        else if (originalSizeMB <= 100) { crf = 25; bps = 900; }
        else { crf = 27; bps = 700; }
        scaleFilter = "scale=720:-2";
    } else if (duration < 60) { crf = 20; bps = 1800; scaleFilter = "scale=720:-2"; }
    else if (duration > 180) { crf = 28; bps = 650; scaleFilter = "scale=720:-2"; }
    if (width < 1280) { scaleFilter = "scale=540:-2"; }

    return new Promise((resolve, reject) => {
        ffmpeg(inputPath).videoFilters(scaleFilter).outputOptions([
            "-c:v libx264", `-b:v ${bps}k`, `-maxrate ${bps}k`, `-bufsize ${bps * 2}k`, `-crf ${crf}`,
            "-preset veryfast", "-c:a aac", "-b:a 128k", "-movflags +faststart", "-y"
        ]).save(outputPath)
          .on("end", () => { console.log("✅ [compressVideo] Completed!"); resolve(); })
          .on("error", (err) => { console.error("❌ [compressVideo] Error:", err); reject(err); });
    });
}

function getAudioDuration(filePath) {
    return new Promise((resolve, reject) => {
        ffmpeg.ffprobe(filePath, (err, metadata) => {
            if (err) { console.error("❌ [getAudioDuration] Error:", err); return reject(err); }
            const duration = metadata?.format?.duration;
            if (duration && !isNaN(parseFloat(duration))) resolve(Math.round(parseFloat(duration)));
            else resolve(0);
        });
    });
}

function getMediaDurationSec(filePath) {
    return new Promise((resolve, reject) => {
        ffmpeg.ffprobe(filePath, (err, metadata) => {
            if (err) { console.error("❌ [getMediaDurationSec] Error:", err); return reject(err); }
            const duration = parseFloat(metadata?.format?.duration);
            resolve(Number.isFinite(duration) && duration > 0 ? duration : 0);
        });
    });
}

function sanitizeCdnUrl(url) {
    if (!url || typeof url !== "string") return "";
    let s = url.trim();
    while (s.length > 0) {
        if (s.endsWith("%22")) { s = s.slice(0, -3).trimEnd(); continue; }
        if (s.endsWith('"') || s.endsWith("'")) { s = s.slice(0, -1).trimEnd(); continue; }
        break;
    }
    return s;
}

async function muxMusicOverVideo({ videoPath, audioPath, outputPath, musicStartSec = 0, durationSec, musicVolume = 1, originalVolume = 0 }) {
    console.log(`🎵 [muxMusicOverVideo] Muxing started. Video: ${videoPath}, Audio: ${audioPath}`);
    const dur = Math.max(0.1, durationSec);
    const seek = Math.max(0, musicStartSec);
    const seekStr = seek.toFixed(3); const durStr = dur.toFixed(3);
    const mv = Math.min(1, Math.max(0, Number(musicVolume) || 0));
    const ov = Math.min(1, Math.max(0, Number(originalVolume) || 0));
    const mixOriginal = ov > 0.01;
    const trimmedMusic = `[1:a]atrim=start=${seekStr}:duration=${durStr},asetpts=PTS-STARTPTS,volume=${mv.toFixed(4)}`;

    return new Promise((resolve, reject) => {
        const cmd = ffmpeg(videoPath).input(audioPath);
        if (mixOriginal) {
            cmd.complexFilter([ `[0:a]volume=${ov.toFixed(4)}[orig]`, `${trimmedMusic}[music]`, `[orig][music]amix=inputs=2:duration=first:dropout_transition=0[aout]` ]);
        } else {
            cmd.complexFilter([`${trimmedMusic}[aout]`]);
        }
        cmd.outputOptions([ "-map", "0:v:0", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-y" ]);
        cmd.save(outputPath)
           .on("end", () => { console.log("✅ [muxMusicOverVideo] Muxing completed!"); resolve(); })
           .on("error", (err) => { console.error("❌ [muxMusicOverVideo] Error:", err); reject(err); });
    });
}

async function downloadFileToTemp(url, ext = '.tmp') {
    console.log(`📥 [downloadFileToTemp] Starting download for: ${url.substring(0, 50)}...`);
    const MAX_REDIRECTS = 5; let redirects = 0; let currentUrl = url;
    const tmpFile = tmp.fileSync({ postfix: ext });
    return new Promise((resolve, reject) => {
        function getFile(fileUrl) {
            if (redirects >= MAX_REDIRECTS) { 
                tmpFile.removeCallback(); 
                console.error("❌ [downloadFileToTemp] Exceeded maximum redirects.");
                return reject(new Error('Exceeded maximum redirects.')); 
            }
            const getter = (fileUrl.startsWith("http://") ? http : https);
            getter.get(fileUrl, (response) => {
                const statusCode = response.statusCode;
                if (statusCode >= 300 && statusCode < 400 && response.headers.location) {
                    redirects++; currentUrl = new URL(response.headers.location, fileUrl).href; 
                    console.log(`🔄 [downloadFileToTemp] Redirecting to: ${currentUrl.substring(0, 50)}...`);
                    response.resume(); return getFile(currentUrl); 
                }
                if (statusCode === 200) {
                    const file = fs.createWriteStream(tmpFile.name);
                    response.pipe(file);
                    file.on("finish", () => { 
                        file.close(() => {
                            console.log(`✅ [downloadFileToTemp] Download finished. Saved at: ${tmpFile.name}`);
                            resolve(tmpFile);
                        }); 
                    });
                    file.on("error", (err) => { 
                        tmpFile.removeCallback(); 
                        console.error("❌ [downloadFileToTemp] File write error:", err);
                        reject(err); 
                    });
                    return;
                }
                tmpFile.removeCallback(); 
                console.error(`❌ [downloadFileToTemp] Failed with Status Code: ${statusCode}`);
                return reject(new Error(`Failed to download file, Status Code: ${statusCode}`));
            }).on("error", (err) => { 
                tmpFile.removeCallback(); 
                console.error("❌ [downloadFileToTemp] HTTP request error:", err);
                reject(err); 
            });
        }
        getFile(currentUrl);
    });
}

// =================================================================
// === 3. CORE WORKER PROCESSING FUNCTION ===
// =================================================================
async function processReelUpload(jobData) {
    console.log(`\n======================================================`);
    console.log(`🚀 [WORKER: FULL UPLOAD JOB STARTED for user ${jobData.userid}]`);
    console.log(`🔍 [JOB DATA RECIEVED] Reel ID: ${jobData.reelId}, RawVideoUrl: ${jobData.rawVideoUrl ? "YES" : "NO"}`);
    
    const { rawVideoUrl, rawThumbnailUrl, videoOriginalname, reelId: existingReelId, externalAudioData, ...reelMetadata } = jobData;
    
    const {
        user, userid, username, name, caption, musicId,
        videoStartTime, videoEndTime, musicStartTime, musicEndTime,
    } = reelMetadata;
    const musicVol = Math.min(1, Math.max(0, parseFloat(externalAudioData?.musicVolume ?? 1)));
    const originalVol = Math.min(1, Math.max(0, parseFloat(externalAudioData?.originalVolume ?? 0)));

    const tempFiles = [];
    let videoFileWithFinalAudioPath = null;
    let finalMusicId = musicId || null;
    let newReelId = existingReelId;
    let savedReel = null;
    let hlsDir = null;

    try {
        if (newReelId) {
            console.log(`🔍 Fetching stub reel from DB: ${newReelId}`);
            savedReel = await Reel.findById(newReelId);
            if (!savedReel) {
                console.error(`❌ Reel stub not found in DB: ${newReelId}`);
                throw new Error(`Reel stub not found: ${newReelId}`);
            }
            console.log(`✅ Stub reel found in DB.`);
        }

        console.log("-> 📥 Downloading Raw Video from S3...");
        const inputTmp = await downloadFileToTemp(rawVideoUrl, path.extname(videoOriginalname) || ".mp4");
        tempFiles.push(inputTmp);
        console.log(`✅ Raw Video downloaded to: ${inputTmp.name}`);

        const outputTmp = tmp.fileSync({ postfix: ".mp4" });
        tempFiles.push(outputTmp);

        let videoToCompressPath = inputTmp.name;
        const videoStartMs = parseFloat(videoStartTime);
        const videoEndMs = parseFloat(videoEndTime);
        
        console.log(`⏱️ Video Trim Info: Start=${videoStartMs}ms, End=${videoEndMs}ms`);
        if (Number.isFinite(videoStartMs) && Number.isFinite(videoEndMs)) {
            const startSec = videoStartMs / 1000;
            const dur = (videoEndMs - videoStartMs) / 1000;
            if (dur > 0) {
                console.log(`✂️ Trimming video... Start: ${startSec}s, Duration: ${dur}s`);
                const trimmedTmp = tmp.fileSync({ postfix: ".mp4" });
                tempFiles.push(trimmedTmp);
                await new Promise((resolve, reject) => {
                    ffmpeg(inputTmp.name).seekInput(startSec).duration(dur)
                        .outputOptions(["-c", "copy", "-y"])
                        .save(trimmedTmp.name)
                        .on("end", () => { console.log("✅ Video trim complete."); resolve(); })
                        .on("error", (err) => { console.error("❌ Video trim error:", err); reject(err); });
                });
                videoToCompressPath = trimmedTmp.name;
            }
        }

        console.log("-> ⚡ BYPASSING Backend Compression for Faster Upload...");
        fs.copyFileSync(videoToCompressPath, outputTmp.name);

        videoFileWithFinalAudioPath = outputTmp.name;

        let shouldReplaceAudio = false;
        let audioInputPath = null;
        let audioDuration = 0; 

        if (externalAudioData && externalAudioData.url && (!musicId || !mongoose.Types.ObjectId.isValid(musicId))) {
            console.log("[STEP 3.0] 🎵 Processing external audio data from body (new Music track)...");
            try {
                const title = externalAudioData.title || "External Sound";
                const artist = externalAudioData.artist || "Unknown Artist";
                console.log(`🔍 Checking if music exists in DB: Title="${title}", Artist="${artist}"`);
                const existingMusic = await Music.findOne({ title, artist });

                if (existingMusic) {
                    console.log(`✅ Existing music found in DB. ID: ${existingMusic._id}`);
                    finalMusicId = existingMusic._id;
                    shouldReplaceAudio = true;
                    const ext = path.extname(existingMusic.url) || '.mp3';
                    console.log("📥 Downloading existing music file...");
                    const musicTmpObj = await downloadFileToTemp(existingMusic.url, ext);
                    tempFiles.push(musicTmpObj);
                    audioInputPath = musicTmpObj.name;  
                } else {
                    console.log("🆕 New external music detected. Downloading...");
                    const ext = path.extname(new URL(externalAudioData.url).pathname) || '.mp3';
                    const musicTmpObj = await downloadFileToTemp(externalAudioData.url, ext);
                    tempFiles.push(musicTmpObj);
                    audioInputPath = musicTmpObj.name;
                    audioDuration = await getAudioDuration(audioInputPath);

                    console.log("📤 Uploading new external music to S3...");
                    const audioBuffer = fs.readFileSync(audioInputPath);
                    const audioUploadResult = await uploadToS3(
                        { buffer: audioBuffer, originalname: `external-sound-${userid}-${Date.now()}${ext}`, mimetype: ext === '.mp3' ? "audio/mp3" : "audio/mpeg" },
                        `audio`
                    );
                    console.log(`✅ New external music uploaded to S3: ${audioUploadResult}`);

                    console.log("💾 Saving new music doc to DB...");
                    const newMusic = new Music({
                        title, artist, url: audioUploadResult, duration: audioDuration,
                        uploadedBy: user, thumbnail: externalAudioData.artwork || "",
                    });
                    const savedMusic = await newMusic.save();
                    finalMusicId = savedMusic._id;
                    shouldReplaceAudio = true;
                    console.log(`✅ New music saved. ID: ${finalMusicId}`);
                }
            } catch (e) {
                console.warn("⚠️ [WARNING] External audio failed:", e.message);
                audioInputPath = null; finalMusicId = musicId || null;
            }
        }

        if (!shouldReplaceAudio && finalMusicId && mongoose.Types.ObjectId.isValid(finalMusicId)) {
            console.log(`🔍 Checking provided musicId: ${finalMusicId}`);
            const musicDoc = await Music.findById(finalMusicId);
            if (musicDoc?.url) {
                console.log("📥 Downloading requested music file from existing ID...");
                const ext = path.extname(musicDoc.url) || '.mp3';
                const musicTmpObj = await downloadFileToTemp(musicDoc.url, ext);
                tempFiles.push(musicTmpObj);
                audioInputPath = musicTmpObj.name;
                shouldReplaceAudio = true;
                console.log("✅ Music file downloaded.");
            }
        }
        
        if (shouldReplaceAudio) {
            console.log("🔀 Replacing/Muxing audio into video...");
            const replacedTmp = tmp.fileSync({ postfix: ".mp4" });
            tempFiles.push(replacedTmp);
            const videoDurationSec = await getMediaDurationSec(outputTmp.name);
            const musicStartMs = Number.isFinite(parseFloat(musicStartTime)) ? parseFloat(musicStartTime) : 0;
            const musicEndMs = Number.isFinite(parseFloat(musicEndTime)) ? parseFloat(musicEndTime) : 0;
            let muxDurationSec = videoDurationSec;
            if (musicEndMs > musicStartMs) {
                muxDurationSec = Math.min(videoDurationSec, (musicEndMs - musicStartMs) / 1000);
            }
            console.log(`🎵 Mux info - MusicStart: ${musicStartMs}ms, MuxDuration: ${muxDurationSec}s`);
            await muxMusicOverVideo({
                videoPath: outputTmp.name, audioPath: audioInputPath, outputPath: replacedTmp.name,
                musicStartSec: musicStartMs / 1000, durationSec: muxDurationSec, musicVolume: musicVol, originalVolume: originalVol,
            });
            videoFileWithFinalAudioPath = replacedTmp.name;
        } else {
            console.log("🎧 No external audio replace requested. Checking for original audio stream...");
            
            // 🔥 FIXED LOGIC: Pehle check karo ki video mein audio track hai ya nahi
            const hasAudio = await new Promise((resolve) => {
                ffmpeg.ffprobe(outputTmp.name, (err, metadata) => {
                    if (err) {
                        resolve(false);
                    } else {
                        // Check if streams exist and find audio
                        const audioStream = metadata.streams && metadata.streams.find(s => s.codec_type === 'audio');
                        resolve(!!audioStream);
                    }
                });
            });

            if (hasAudio) {
                console.log("🔉 Original audio stream found. Extracting...");
                const extractedAudioTmp = tmp.fileSync({ postfix: ".mp3" });
                tempFiles.push(extractedAudioTmp);
                await new Promise((resolve, reject) => {
                    ffmpeg(outputTmp.name).outputOptions(["-vn", "-c:a libmp3lame", "-b:a 128k", "-y"])
                        .save(extractedAudioTmp.name)
                        .on("end", () => { console.log("✅ Original audio extracted."); resolve(); })
                        .on("error", (err) => { console.error("❌ Audio extraction error:", err); reject(err); });
                });
                
                console.log("📤 Uploading extracted original audio to S3...");
                const audioBuffer = fs.readFileSync(extractedAudioTmp.name);
                const audioUploadResult = await uploadToS3(
                    { buffer: audioBuffer, originalname: `original-sound-${userid}-${Date.now()}.mp3`, mimetype: "audio/mp3" }, `audio`
                );
                
                let originalAudioDuration = 0;
                const videoDurationMs = (parseFloat(videoEndTime) - parseFloat(videoStartTime));
                if (!isNaN(videoDurationMs) && videoDurationMs > 0) originalAudioDuration = Math.round(videoDurationMs / 1000);

                console.log("💾 Saving original audio as new Music doc...");
                const newMusic = new Music({
                    title: caption ? `${caption.substring(0, 50)}... (Original Sound)` : "Original Video Sound",
                    artist: name || username || 'Unknown User', url: audioUploadResult,
                    duration: originalAudioDuration, uploadedBy: user, thumbnail: '',
                });
                const savedMusic = await newMusic.save();
                finalMusicId = savedMusic._id;
                console.log(`✅ Original audio saved. ID: ${finalMusicId}`);
            } else {
                console.log("🔇 No audio stream found in the uploaded video. Skipping audio extraction.");
                finalMusicId = null; // Silent video hai toh music null set kardo
            }
        }

        console.log("👤 Updating user/reel metadata in DB...");
        const uploaderUser = await User.findById(user);
        if (savedReel) {
            savedReel.music = finalMusicId; savedReel.caption = caption ?? savedReel.caption;
            savedReel.username = username || savedReel.username; savedReel.name = name || savedReel.name;
            await savedReel.save();
            console.log("✅ Reel stub updated with final metadata.");
        } 

        try {
            if (uploaderUser && savedReel.shortLinks.length === 0) {
                console.log("🔗 Generating short link for Reel...");
                const { slug, shortLink } = generateShortLink(savedReel._id, uploaderUser.userid);
                savedReel.shortLinks.push({ slug, shortLink, generatedForUser: uploaderUser._id, generatedAt: new Date() });
                await savedReel.save();
                console.log(`✅ Short link generated: ${shortLink}`);
            }
        } catch (shortLinkError) {
            console.warn("⚠️ [WARNING] Failed to generate short link:", shortLinkError.message);
        }

        console.log("[STEP 5] ⚙️ Generating HLS segments (Priority 1: 480p for Instant Live)...");
        hlsDir = path.join(os.tmpdir(), `hls-${newReelId}`);
        fs.mkdirSync(hlsDir, { recursive: true });

        const generateAndUploadVariant = async (variant) => {
            console.log(`🎬 Generating HLS variant: ${variant.name} (${variant.resolution})...`);
            const variantDir = path.join(hlsDir, variant.name);
            fs.mkdirSync(variantDir, { recursive: true });
            const segmentPattern = path.join(variantDir, "segment_%03d.ts").replace(/\\/g, '/');
            const outputPath = path.join(variantDir, "index.m3u8").replace(/\\/g, '/');

            await new Promise((resolve, reject) => {
                ffmpeg(videoFileWithFinalAudioPath)
                    .videoFilters(`scale=${variant.resolution}:force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2`)
                    .videoCodec('libx264').audioCodec('aac')
                    .addOutputOptions([
                        "-preset", "veryfast", `-b:v ${variant.videoBitrate}`, `-maxrate ${variant.videoBitrate}`, `-bufsize ${parseInt(variant.videoBitrate) * 2}k`, `-b:a ${variant.audioBitrate}`,
                        "-sc_threshold", "0", "-g", `${24 * variant.hlsTime}`, "-keyint_min", `${24 * variant.hlsTime}`, "-force_key_frames", `expr:gte(t,n_forced*${variant.hlsTime})`,
                        "-hls_time", `${variant.hlsTime}`, "-hls_playlist_type", "vod", "-hls_list_size", "0", "-hls_flags", "independent_segments", "-hls_segment_type", "mpegts",
                        `-hls_segment_filename`, segmentPattern, "-f", "hls", "-y",
                    ])
                    .output(outputPath)
                    .on("end", () => { console.log(`✅ HLS variant ${variant.name} generation complete.`); resolve(); })
                    .on("error", (err) => { console.error(`❌ HLS variant ${variant.name} error:`, err); reject(err); })
                    .run();
            });

            console.log(`📤 Uploading ${variant.name} HLS segments to S3...`);
            const files = fs.readdirSync(variantDir).filter(f => fs.statSync(path.join(variantDir, f)).isFile());
            const uploadPromises = files.map(file => {
                const filePath = path.join(variantDir, file);
                const buffer = fs.readFileSync(filePath);
                const s3Folder = `videos/reels/${newReelId}/${variant.name}`; 
                const mimetype = file.endsWith(".m3u8") ? "application/vnd.apple.mpegurl" : file.endsWith(".ts") ? "video/mp2t" : "application/octet-stream";
                return uploadToS3({ buffer, originalname: file, mimetype }, s3Folder, true);
            });
            while (uploadPromises.length > 0) { 
                await Promise.all(uploadPromises.splice(0, 4)); 
            }
            console.log(`✅ Upload complete for ${variant.name}`);
        };

        await generateAndUploadVariant({ name: "480p", resolution: "854x480", videoBitrate: "1100k", audioBitrate: "128k", bandwidth: 1400000, hlsTime: 2 });

        console.log("📝 Generating Master Playlist (m3u8)...");
        const masterPlaylistContent = `#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-INDEPENDENT-SEGMENTS\n#EXT-X-STREAM-INF:BANDWIDTH=380000,RESOLUTION=426x240\n240p/index.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=1400000,RESOLUTION=854x480\n480p/index.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=2500000,RESOLUTION=1280x720\n720p/index.m3u8\n`;
        fs.writeFileSync(path.join(hlsDir, "master.m3u8"), masterPlaylistContent);
        console.log("📤 Uploading Master Playlist to S3...");
        await uploadToS3({ buffer: fs.readFileSync(path.join(hlsDir, "master.m3u8")), originalname: "master.m3u8", mimetype: "application/vnd.apple.mpegurl" }, `videos/reels/${newReelId}`, true);

        // THUMBNAIL LOGIC
        console.log("🖼️ Processing Thumbnail...");
        let thumbnailUrl = rawThumbnailUrl; 
        if (!thumbnailUrl) {
            console.log("📸 Generating thumbnail from video frame...");
            const thumbTmp = tmp.fileSync({ postfix: ".jpg" });
            tempFiles.push(thumbTmp);
            await new Promise((resolve, reject) => {
                ffmpeg(videoFileWithFinalAudioPath).screenshots({ timestamps: [0], filename: path.basename(thumbTmp.name), folder: path.dirname(thumbTmp.name), size: "640x?" })
                .on("end", () => { console.log("✅ Thumbnail frame captured."); resolve(); })
                .on("error", (err) => { console.error("❌ Thumbnail capture error:", err); reject(err); });
            });
            console.log("📤 Uploading generated thumbnail to S3...");
            thumbnailUrl = await uploadToS3({ buffer: fs.readFileSync(thumbTmp.name), originalname: `thumb-${newReelId}.jpg`, mimetype: "image/jpeg" }, "thumbnails");
        } else {
            console.log("✅ Using provided rawThumbnailUrl");
        }

        if (!musicId && finalMusicId) {
            console.log(`💾 Updating music document with thumbnail...`);
            await Music.findByIdAndUpdate(finalMusicId, { thumbnail: thumbnailUrl });
        }

        console.log("💾 Updating Reel DB document to 'Published'...");
        const videoUrl = `https://${process.env.CLOUDFRONT_URL}/videos/reels/${newReelId}/master.m3u8`;
        savedReel.videoUrl = sanitizeCdnUrl(videoUrl);
        savedReel.thumbnailUrl = sanitizeCdnUrl(thumbnailUrl);
        savedReel.status = 'Published'; 
        savedReel.qualityVariants = ["480p"];
        await savedReel.save();
        console.log("===== 🟢 [PRIORITY DONE: REEL IS PUBLISHED & LIVE!] =====");

        console.log("⚙️ Starting background generation of remaining qualities (240p, 720p)...");
        const remainingVariants = [
            { name: "240p", resolution: "426x240", videoBitrate: "350k", audioBitrate: "64k", bandwidth: 450000, hlsTime: 2 },
            { name: "720p", resolution: "1280x720", videoBitrate: "2000k", audioBitrate: "160k", bandwidth: 2500000, hlsTime: 2 }
        ];
        for (const variant of remainingVariants) {
            await generateAndUploadVariant(variant);
        }

        console.log("💾 Updating Reel DB document with all quality variants...");
        await Reel.findByIdAndUpdate(newReelId, { $addToSet: { qualityVariants: { $each: ["240p", "720p"] } } });
        console.log("===== 🎉 [WORKER: FULL UPLOAD SUCCESS - ALL QUALITIES READY] =====");

        // ========================================================
        // 🗑️ STORAGE OPTIMIZATION: Delete Raw MP4 from S3 after processing
        // ========================================================
        try {
            if (rawVideoUrl) {
                const urlObj = new URL(rawVideoUrl);
                const rawKey = urlObj.pathname.startsWith('/') ? urlObj.pathname.substring(1) : urlObj.pathname;
                console.log(`🧹 Cleaning up S3... Deleting raw file: ${rawKey}`);
                
                await s3.send(new DeleteObjectCommand({
                    Bucket: process.env.AWS_BUCKET_NAME,
                    Key: decodeURIComponent(rawKey),
                }));
                console.log("✅ Raw MP4 deleted successfully! Storage space saved.");
            }
        } catch (deleteError) {
            console.error("⚠ Non-blocking Error: Raw MP4 delete nahi ho payi:", deleteError.message);
        }

    } catch (err) {
        console.error("\n===== ❌ [WORKER: FULL UPLOAD FATAL ERROR] =====");
        console.error(err.stack || err.message || err);
        if (newReelId) {
            console.log(`⚠️ Updating Reel ${newReelId} status to 'failed' in DB...`);
            await Reel.findByIdAndUpdate(newReelId, { status: 'failed', error: err.message });
        }
        throw err;
    } finally {
        console.log("🧹 Running local cleanup for temp files...");
        tempFiles.forEach((t) => { 
            try { if (t) t.removeCallback(); } catch (e) { console.error("Temp file delete err:", e); } 
        });
        if (hlsDir) { 
            try { fs.rmSync(hlsDir, { recursive: true, force: true }); } catch (e) { console.error("HLS dir delete err:", e); } 
        }
        console.log("✅ Cleanup done. Worker ready for next job.\n======================================================\n");
    }
}

// Start BullMQ Worker
const redisConnection = new IORedis({ maxRetriesPerRequest: null }); 

redisConnection.on('connect', () => console.log("✅ Worker connected to Redis"));
redisConnection.on('error', (err) => console.error("❌ Redis connection error:", err));

const worker = new Worker('reel-processing', async job => {
    console.log(`\n🔔 Worker picked up job ID: ${job.id}`);
    await processReelUpload(job.data);
}, { connection: redisConnection, concurrency: 4 }); // concurrency 4 means it processes 4 videos simultaneously

worker.on('active', job => { console.log(`▶️ Job ${job.id} is now ACTIVE.`); });
worker.on('completed', job => { console.log(`🏁 Job ${job.id} has COMPLETED successfully!`); });
worker.on('failed', (job, err) => { console.error(`❌ Job ${job.id} has FAILED with error: ${err.message}`); });
worker.on('error', err => { console.error(`⚠️ Worker caught an error:`, err); });
worker.on('stalled', (jobId) => { console.warn(`⚠️ Job ${jobId} has stalled!`); });

console.log("🚀 Background Worker is running and waiting for jobs...");