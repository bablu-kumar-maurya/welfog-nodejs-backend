const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");


const roleSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    permissions: {
      type: [String],
      default: [],
    },
  },
  {
    _id: true,
    timestamps: true, 
  }
);
const adminSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    role: {
      type: String,
      enum: ["admin", "superadmin"],
      default: "admin",
    },
    roles: {
      type: [roleSchema],
      default: [],
    },
    profileImage: {
      type: String,
      default: null,
    },
    siteName: {
      type: String,
      default: 'Welfog Internet Private Limited',
    },
    maintenanceMode: {
      type: Boolean,
      default: false,
    },
    allowNewRegistrations: {
      type: Boolean,
      default: true,
    },
    maxUploadSize: {
      type: Number,
      default: 200,
    },
    videoQuality: {
      type: String,
      enum: ['low', 'medium', 'high'],
      default: 'high',
    },
    lastLogin: Date,

    // 👇 Yahan ye dono fields add karni hain
    isDeleted: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      default: null,
    }
  },
  { timestamps: true }
);

// ================= PASSWORD HASH =================
adminSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// ================= PASSWORD COMPARE =================
adminSchema.methods.comparePassword = function (password) {
  return bcrypt.compare(password, this.password);
};

module.exports = mongoose.model("Admin", adminSchema);